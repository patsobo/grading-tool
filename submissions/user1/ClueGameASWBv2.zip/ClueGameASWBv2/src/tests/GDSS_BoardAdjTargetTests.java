package tests;
import java.util.Set;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import clueGame.Board;
import clueGame.BoardCell;

public class GDSS_BoardAdjTargetTests {
	private static Board board;
	@BeforeClass
	public static void setBoard() {
		board = Board.getInstance();
		board.setConfigFiles("GDSS_ClueLayout.csv", "legend.txt");
		board.initialize();
	}
	
	//Blue: Testing adjacencies of doors to be 1
	@Test
	public void testAdjAtDoorway() {
		//right door
		Set<BoardCell> testingAdj = board.getAdjList(1, 1);
		assertEquals(1, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(1, 2)));
		//down door touching three walkways
		testingAdj = board.getAdjList(6, 9);
		assertEquals(1, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(7, 9)));
		//up door touching one walkway
		testingAdj = board.getAdjList(11, 2);
		assertEquals(1, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(10, 2)));
		//right door touching three walkways
		testingAdj = board.getAdjList(15, 6);
		assertEquals(1, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(15, 7)));
		//left door next to another left door
		testingAdj = board.getAdjList(8, 17);
		assertEquals(1, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(8, 16)));
	}
	
	//Orange: Testing adjacencies in a room
	@Test
	public void testAdjInRoom() {
		//corner of room
		Set<BoardCell> testingAdj = board.getAdjList(11, 6);
		assertEquals(0, testingAdj.size());
		//edge of room next to door
		testingAdj = board.getAdjList(16, 11);
		assertEquals(0, testingAdj.size());
		//middle of room
		testingAdj = board.getAdjList(13, 18);
		assertEquals(0, testingAdj.size());
	}
	
	//Dark Red: Testing adjacencies surrounded by walkway
	@Test
	public void testAdjOnlyWalkway() {
		Set<BoardCell> testingAdj = board.getAdjList(9, 5);
		assertEquals(4, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(9, 6)));
		assertTrue(testingAdj.contains(board.getCellAt(9, 4)));
		assertTrue(testingAdj.contains(board.getCellAt(8, 5)));
		assertTrue(testingAdj.contains(board.getCellAt(10, 5)));
	}
	
	//Light Blue: Testing adjacencies of cells next to room
	@Test
	public void testAdjNextToRoom() {
		Set<BoardCell> testingAdj = board.getAdjList(6, 4);
		assertEquals(3, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(5, 4)));
		assertTrue(testingAdj.contains(board.getCellAt(7, 4)));
		assertTrue(testingAdj.contains(board.getCellAt(6, 5)));
		
		testingAdj = board.getAdjList(10, 4);
		assertEquals(3, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(9, 4)));
		assertTrue(testingAdj.contains(board.getCellAt(10, 3)));
		assertTrue(testingAdj.contains(board.getCellAt(10, 5)));
	}
	
	//White: Testing adjacencies of cells next to doors
	@Test
	public void testAdjNextToDoor() {
		//RIGHT
		Set<BoardCell> testingAdj = board.getAdjList(1, 2);
		assertEquals(3, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(1, 1)));
		
		//LEFT
		testingAdj = board.getAdjList(18,7);
		assertEquals(4, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(18, 8)));
		
		//DOWN
		testingAdj = board.getAdjList(7, 8);
		assertEquals(3, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(6, 8)));
		
		//UP
		testingAdj = board.getAdjList(15,17);
		assertEquals(3, testingAdj.size());
		assertTrue(testingAdj.contains(board.getCellAt(16, 17)));
	}
	
	//Light Green: Testing adjacencies of cells at each edge
	@Test
	public void testAdjEachEdge() {
		//Left
		Set<BoardCell> testingAdj = board.getAdjList(10, 0);
		assertEquals(3, testingAdj.size());
		//Top
		testingAdj = board.getAdjList(0, 10);
		assertEquals(2, testingAdj.size());
		//Bottom
		testingAdj = board.getAdjList(20, 19);
		assertEquals(2, testingAdj.size());
		//Right touching bottom
		testingAdj = board.getAdjList(20, 20);
		assertEquals(2, testingAdj.size());
	}
	
	//Purple: Testing Targets along walkways at various distances
	@Test
	public void testTargetsAlongWalkways() {
		//ONE STEP
		board.calcTargets(13, 9, 1);
		Set<BoardCell> targets = board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCellAt(13, 8)));
		assertTrue(targets.contains(board.getCellAt(14, 9)));	
		
		board.calcTargets(15, 7, 1);
		targets = board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCellAt(15, 8)));
		assertTrue(targets.contains(board.getCellAt(15, 6)));
		assertTrue(targets.contains(board.getCellAt(14, 7)));
		assertTrue(targets.contains(board.getCellAt(16, 7)));
		//TWO STEP
		board.calcTargets(12, 15, 2);
		targets = board.getTargets();
		assertEquals(6, targets.size());
		assertTrue(targets.contains(board.getCellAt(13, 14)));
		assertTrue(targets.contains(board.getCellAt(13, 16)));
		assertTrue(targets.contains(board.getCellAt(14, 15)));
		assertTrue(targets.contains(board.getCellAt(12, 17)));
		assertTrue(targets.contains(board.getCellAt(11, 16)));
		assertTrue(targets.contains(board.getCellAt(10, 15)));
		
		board.calcTargets(4, 17, 2);
		targets = board.getTargets();
		assertEquals(6, targets.size());
		assertTrue(targets.contains(board.getCellAt(3, 18)));
		assertTrue(targets.contains(board.getCellAt(4, 19)));
		assertTrue(targets.contains(board.getCellAt(5, 18)));
		assertTrue(targets.contains(board.getCellAt(5, 16)));
		assertTrue(targets.contains(board.getCellAt(4, 15)));
		assertTrue(targets.contains(board.getCellAt(3, 16)));
		//SIX STEP
		//just want to make sure we get the doorway here
		board.calcTargets(0, 5, 6);
		targets = board.getTargets();
		assertEquals(9, targets.size());
		assertTrue(targets.contains(board.getCellAt(1, 1)));
		
		board.calcTargets(15, 0, 6);
		targets = board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCellAt(9, 0)));
		assertTrue(targets.contains(board.getCellAt(10, 1)));
		assertTrue(targets.contains(board.getCellAt(20, 1)));
	}
	
	//Yellow: Testing Targets that allow user to enter oom
	@Test
	public void testTargetEnterRoom() {
		//1 step enter
		board.calcTargets(10, 2, 1);
		Set<BoardCell> targets = board.getTargets();
		assertTrue(targets.contains(board.getCellAt(11, 2)));
		
		//5 step enter
		board.calcTargets(4, 20, 5);
		targets = board.getTargets();
		assertTrue(targets.contains(board.getCellAt(3, 18)));
		assertTrue(targets.contains(board.getCellAt(3, 19)));
	}
	
	//Testing targets when user exits room
	@Test
	public void testTargetExitRoom() {
		//1 step exit
		board.calcTargets(1, 8, 1);
		Set<BoardCell> targets = board.getTargets();
		assertEquals(1, targets.size());
		assertTrue(targets.contains(board.getCellAt(1, 9)));

		//2 step exit
		board.calcTargets(6, 13, 2);
		targets = board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCellAt(7, 14)));
		assertTrue(targets.contains(board.getCellAt(7, 12)));
		assertTrue(targets.contains(board.getCellAt(8, 13)));
	}
}
