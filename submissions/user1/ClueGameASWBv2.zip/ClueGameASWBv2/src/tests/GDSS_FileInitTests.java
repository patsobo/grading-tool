package tests;
import static org.junit.Assert.*;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.DoorDirection;

public class GDSS_FileInitTests {
	public static final int LEGEND_SIZE = 11;
	public static final int NUM_ROWS = 21;
	public static final int NUM_COLUMNS = 21;
	public static final int NUM_DOORS = 21;
	
	private static Board board;
	
	@BeforeClass
	public static void setBoard() {
		board = Board.getInstance();
		board.setConfigFiles("GDSS_ClueLayout.csv", "legend.txt");
		board.initialize();
	}
	
	@Test
	public void testLegendFile() {
		Map<Character, String> legend = board.getLegend();
		assertEquals(LEGEND_SIZE, legend.size());
		assertEquals("Bedroom", legend.get('B'));
		assertEquals("Dungeon", legend.get('D'));
		assertEquals("Gunroom", legend.get('G'));
		assertEquals("Kitchen", legend.get('K'));
		assertEquals("Library", legend.get('L'));
		assertEquals("Mailroom", legend.get('M'));
		assertEquals("President-Suite", legend.get('P'));
		assertEquals("Sauna", legend.get('S'));
		assertEquals("Table-Tennis", legend.get('T'));
		assertEquals("Closet", legend.get('X'));
		assertEquals("Walkway", legend.get('W'));
	}
	
	@Test
	public void testRowColumnNums() {
		assertEquals(NUM_ROWS, board.getNumRows());
		assertEquals(NUM_COLUMNS, board.getNumColumns());
	}
	
	@Test
	public void testDoorwayDirection() {
		//test Mailroom
		BoardCell cell = board.getCellAt(1, 1);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.RIGHT, cell.getDoorDirection());
		cell = board.getCellAt(8, 1);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.DOWN, cell.getDoorDirection());
		cell = board.getCellAt(0, 0);
		assertFalse(cell.isDoorway());
		//test Library
		cell = board.getCellAt(1, 8);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.RIGHT, cell.getDoorDirection());
		cell = board.getCellAt(6, 8);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.DOWN, cell.getDoorDirection());
		cell = board.getCellAt(0, 6);
		assertFalse(cell.isDoorway());
		//test President-Suite
		cell = board.getCellAt(5, 14);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.RIGHT, cell.getDoorDirection());
		cell = board.getCellAt(6, 13);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.DOWN, cell.getDoorDirection());
		cell = board.getCellAt(0, 11);
		assertFalse(cell.isDoorway());
		//test Sauna
		cell = board.getCellAt(3, 18);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.DOWN, cell.getDoorDirection());
		cell = board.getCellAt(0, 17);
		assertFalse(cell.isDoorway());
		//test Table-Tennis
		cell = board.getCellAt(7, 17);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.LEFT, cell.getDoorDirection());
		cell = board.getCellAt(6, 17);
		assertFalse(cell.isDoorway());
		//test Kitchen
		cell = board.getCellAt(12, 17);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.LEFT, cell.getDoorDirection());
		cell = board.getCellAt(17, 11);
		assertFalse(cell.isDoorway());
		//test Dungeon
		cell = board.getCellAt(16,17);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.UP, cell.getDoorDirection());
		cell = board.getCellAt(17, 17);
		assertFalse(cell.isDoorway());
		//test Gunroom
		cell = board.getCellAt(16,12);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.UP, cell.getDoorDirection());
		cell = board.getCellAt(18,8);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.LEFT, cell.getDoorDirection());
		cell = board.getCellAt(18,14);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.RIGHT, cell.getDoorDirection());
		cell = board.getCellAt(16,8);
		assertFalse(cell.isDoorway());
		//test Bedroom
		cell = board.getCellAt(11,2);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.UP, cell.getDoorDirection());
		cell = board.getCellAt(19,2);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.DOWN, cell.getDoorDirection());
		cell = board.getCellAt(15,6);
		assertTrue(cell.isDoorway());
		assertEquals(DoorDirection.RIGHT, cell.getDoorDirection());
		cell = board.getCellAt(11,1);
		assertFalse(cell.isDoorway());
		//test walkway
		cell = board.getCellAt(1,2);
		assertFalse(cell.isDoorway());
		cell = board.getCellAt(1,3);
		assertFalse(cell.isDoorway());
		cell = board.getCellAt(9,6);
		assertFalse(cell.isDoorway());
		//test closet
		cell = board.getCellAt(10,10);
		assertFalse(cell.isDoorway());
	}
	
	
	@Test
	public void numDoors() {
		int tempNumDoors = 0;
		for(int i = 0; i < NUM_ROWS; i++) {
			for(int j = 0; j < NUM_COLUMNS; j++) {
				BoardCell check = board.getCellAt(i, j);
				if(check.isDoorway()) {
					tempNumDoors++;
				}
			}
		}
		assertEquals(NUM_DOORS, tempNumDoors);
	}
	
	@Test
	public void testInitials() {
		//following are assorted (near door, first, last, corner, etc)
		assertEquals('B', board.getCellAt(11,1).getInitial());
		assertEquals('D', board.getCellAt(19,19).getInitial());
		assertEquals('G', board.getCellAt(16,8).getInitial());
		assertEquals('K', board.getCellAt(11,17).getInitial());
		assertEquals('L', board.getCellAt(0,8).getInitial());
		assertEquals('M', board.getCellAt(0,0).getInitial());
		assertEquals('P', board.getCellAt(0,11).getInitial());
		assertEquals('S', board.getCellAt(3,20).getInitial());
		assertEquals('T', board.getCellAt(6,20).getInitial());
		assertEquals('X', board.getCellAt(10,10).getInitial());
		assertEquals('W', board.getCellAt(20,0).getInitial());
		//edge cases ( literally :) )
		assertEquals('B', board.getCellAt(19,4).getInitial());
		assertEquals('X', board.getCellAt(9,10).getInitial());
		assertEquals('W', board.getCellAt(13,9).getInitial());
		assertEquals('W', board.getCellAt(20,20).getInitial());
	}
	
	
}













