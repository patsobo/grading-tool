package tests;
import clueGame.*;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.*;

import org.junit.Before;
import org.junit.Test;

public class gameSetupTests {
	private static Board board;
	
	@Before
	public void setup() {
		board = Board.getInstance();
		board.setConfigFiles("GDSS_ClueLayout.csv", "legend.txt", "person.txt", "weapon.txt");
		board.initialize();
		
		board.dealCards();
	}
	
	@Test
	public void testRoomCards() {
		assertEquals(21, board.getDeck().size());
		
		Card card = new Card("Bedroom", CardType.ROOM);
		assertTrue(board.getDeck().get("Bedroom").equals(card));
		
		card = new Card("Dungeon", CardType.ROOM);
		assertTrue(board.getDeck().get("Dungeon").equals(card));
		
		card = new Card("Gunroom", CardType.ROOM);
		assertTrue(board.getDeck().get("Gunroom").equals(card));
		
		card = new Card("Kitchen", CardType.ROOM);
		assertTrue(board.getDeck().get("Kitchen").equals(card));
		
		card = new Card("Library", CardType.ROOM);
		assertTrue(board.getDeck().get("Library").equals(card));
		
		card = new Card("Mailroom", CardType.ROOM);
		assertTrue(board.getDeck().get("Mailroom").equals(card));
		
		card = new Card("President-Suite", CardType.ROOM);
		assertTrue(board.getDeck().get("President-Suite").equals(card));
		
		card = new Card("Sauna", CardType.ROOM);
		assertTrue(board.getDeck().get("Sauna").equals(card));
		
		card = new Card("Table-Tennis", CardType.ROOM);
		assertTrue(board.getDeck().get("Table-Tennis").equals(card));
		
	}
	
	@Test
	public void testPersonCards() {
		assertEquals(21, board.getDeck().size());
		
		Card card = new Card("Secretary-Susan", CardType.PERSON);
		assertTrue(board.getDeck().get("Secretary-Susan").equals(card));
		
		card = new Card("Garbageman-Greg", CardType.PERSON);
		assertTrue(board.getDeck().get("Garbageman-Greg").equals(card));
		
		card = new Card("Librarian-Lucy", CardType.PERSON);
		assertTrue(board.getDeck().get("Librarian-Lucy").equals(card));
		
		card = new Card("Congressman-Chris", CardType.PERSON);
		assertTrue(board.getDeck().get("Congressman-Chris").equals(card));
		
		card = new Card("Robot-AI", CardType.PERSON);
		assertTrue(board.getDeck().get("Robot-AI").equals(card));
		
		card = new Card("G-Eazy", CardType.PERSON);
		assertTrue(board.getDeck().get("G-Eazy").equals(card));
	}
	
	@Test
	public void testWeaponCards() {
		assertEquals(21, board.getDeck().size());
		
		Card card = new Card("Machete", CardType.WEAPON);
		assertTrue(board.getDeck().get("Machete").equals(card));
		
		card = new Card("Crowbar", CardType.WEAPON);
		assertTrue(board.getDeck().get("Crowbar").equals(card));
		
		card = new Card("Rifle", CardType.WEAPON);
		assertTrue(board.getDeck().get("Rifle").equals(card));
		
		card = new Card("Hand-Grenage", CardType.WEAPON);
		assertTrue(board.getDeck().get("Hand-Grenage").equals(card));
		
		card = new Card("Revolver", CardType.WEAPON);
		assertTrue(board.getDeck().get("Revolver").equals(card));
		
		card = new Card("Tank", CardType.WEAPON);
		assertTrue(board.getDeck().get("Tank").equals(card));
	}
	
	@Test
	public void testPlayers() {
		assertEquals(6, board.getPlayers().size());
		
		assertEquals("Secretary-Susan", board.getPlayers().get("Secretary-Susan").getName());
		assertEquals("Garbageman-Greg", board.getPlayers().get("Garbageman-Greg").getName());
		assertEquals("Librarian-Lucy", board.getPlayers().get("Librarian-Lucy").getName());
		assertEquals("Congressman-Chris", board.getPlayers().get("Congressman-Chris").getName());
		assertEquals("Robot-AI", board.getPlayers().get("Robot-AI").getName());
		assertEquals("G-Eazy", board.getPlayers().get("G-Eazy").getName());
	}
	
	@Test
	public void testDealing() {
		// Following tests don't work if less than 6 players exist
		assertEquals(6, board.getPlayers().size());
		
		// Make sure all cards are dealt
		Map<String, Card> allCards = new HashMap<String, Card>();
		
		// Make sure solution has valid cards
		Solution soln = board.getSolution();
		
		Card card = new Card(soln.room, CardType.ROOM);
		assertTrue(board.getDeck().get(soln.room).equals(card));
		allCards.put(card.getName(), card);
		
		card = new Card(soln.person, CardType.PERSON);
		assertTrue(board.getDeck().get(soln.person).equals(card));
		allCards.put(card.getName(), card);
		
		card = new Card(soln.weapon, CardType.WEAPON);
		assertTrue(board.getDeck().get(soln.weapon).equals(card));
		allCards.put(card.getName(), card);
		
		// Make sure each player has valid cards

		
		ArrayList<Card> hand = (ArrayList<Card>)board.getPlayers().get("Secretary-Susan").getCards();
		
		assertEquals(3, hand.size());
		assertFalse(board.getDeck().get(hand.get(0).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(1).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(2).getName()).equals(null));
		
		card = board.getDeck().get(hand.get(0).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(1).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(2).getName());
		allCards.put(card.getName(), card);
		
		hand = (ArrayList<Card>)board.getPlayers().get("Garbageman-Greg").getCards();
		
		assertEquals(3, hand.size());
		assertFalse(board.getDeck().get(hand.get(0).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(1).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(2).getName()).equals(null));
		
		card = board.getDeck().get(hand.get(0).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(1).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(2).getName());
		allCards.put(card.getName(), card);
		
		hand = (ArrayList<Card>)board.getPlayers().get("Librarian-Lucy").getCards();
		
		assertEquals(3, hand.size());
		assertFalse(board.getDeck().get(hand.get(0).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(1).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(2).getName()).equals(null));
		
		card = board.getDeck().get(hand.get(0).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(1).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(2).getName());
		allCards.put(card.getName(), card);
		
		hand = (ArrayList<Card>)board.getPlayers().get("Congressman-Chris").getCards();
		
		assertEquals(3, hand.size());
		assertFalse(board.getDeck().get(hand.get(0).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(1).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(2).getName()).equals(null));
		
		card = board.getDeck().get(hand.get(0).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(1).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(2).getName());
		allCards.put(card.getName(), card);
		
		hand = (ArrayList<Card>)board.getPlayers().get("Robot-AI").getCards();
		
		assertEquals(3, hand.size());
		assertFalse(board.getDeck().get(hand.get(0).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(1).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(2).getName()).equals(null));
		
		card = board.getDeck().get(hand.get(0).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(1).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(2).getName());
		allCards.put(card.getName(), card);
		
		hand = (ArrayList<Card>)board.getPlayers().get("G-Eazy").getCards();
		
		assertEquals(3, hand.size());
		assertFalse(board.getDeck().get(hand.get(0).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(1).getName()).equals(null));
		assertFalse(board.getDeck().get(hand.get(2).getName()).equals(null));
		
		card = board.getDeck().get(hand.get(0).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(1).getName());
		allCards.put(card.getName(), card);
		card = board.getDeck().get(hand.get(2).getName());
		allCards.put(card.getName(), card);
		
		// Find if all cards were used. If this fails, there are duplicates in play
		System.out.println(allCards);
		assertEquals(21, allCards.size());
	}
}
