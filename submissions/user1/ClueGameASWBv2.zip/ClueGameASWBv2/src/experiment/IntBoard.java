package experiment;




import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import clueGame.BoardCell;

public class IntBoard {
	private Map<BoardCell, Set<BoardCell>> adjMtx;
	private Set<BoardCell> visited;
	private Set<BoardCell> targets;
	private BoardCell[][] grid;
	
	public IntBoard() {
		grid = new BoardCell[4][4];
		for(int i = 0; i < grid.length; i++) {
			for(int j = 0; j < grid[i].length; j++) {
				grid[i][j] = new BoardCell(i, j);
			}
		}
		adjMtx = new HashMap<BoardCell, Set<BoardCell>>();
		calcAdjacencies();
		
	}
	
	public Map<BoardCell, Set<BoardCell>> calcAdjacencies() {
		for(int i = 0; i < grid.length; i++) {
			for(int j = 0; j < grid[i].length; j++) {
				Set<BoardCell> tmp = new HashSet<BoardCell>();
				if((i - 1) >= 0) {
					tmp.add(grid[i-1][j]);
				}
				if((i + 1) <= 3) {
					tmp.add(grid[i+1][j]);
				}
				if((j - 1) >= 0) {
					tmp.add(grid[i][j-1]);
				}
				if((j + 1) <= 3) {
					tmp.add(grid[i][j+1]);
				}
				adjMtx.put(grid[i][j], tmp);
			}
		}
		return adjMtx;
	}
	
	public void calcTargets(BoardCell cell, int path) {
		visited = new HashSet<BoardCell>();
		targets = new HashSet<BoardCell>();
		visited.add(cell);
		findAllTargets(cell, path);
		return;
	}
	
	public void findAllTargets(BoardCell startCell, int pathLength) {
		for(BoardCell b : adjMtx.get(startCell)) {
			if(visited.contains(b)) {
				continue;
			} else {
				visited.add(b);
				if(pathLength == 1) {
					if(!targets.contains(b)) {
						targets.add(b);
					}
				} else {
					findAllTargets(b, pathLength-1);
				}
				visited.remove(b);
			}
		}
	}
	
	
	public Set<BoardCell> getTargets() {
		return targets;
	}

	public Set<BoardCell> getAdjList(BoardCell cell) {
		return adjMtx.get(cell);
	}

	public BoardCell getCell(int i, int j) {
		return grid[i][j];
	}
	
	
	
	
}
