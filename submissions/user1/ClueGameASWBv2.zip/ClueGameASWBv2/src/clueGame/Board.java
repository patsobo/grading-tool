package clueGame;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Board {
	//variable used for singleton pattern
	private static Board theInstance = new Board();
	//ctor is private to ensure only one can be created
	private Board() {}
	// this method returns the only Board
	
	private static final int MAX_BOARD_SIZE = 40;
	private Map<Character, String> rooms;
	private Set<BoardCell> targets;
	private BoardCell[][] board;
	
	private String roomConfigFile;
	private String boardConfigFile;
	private String weaponConfigFile = "";
	private String personConfigFile = "";
	
	private Map<String, Card> deck = new HashMap<String, Card>();
	private Map<String, Card> peopleDeck = new HashMap<String, Card>();
	private Map<String, Card> roomDeck = new HashMap<String, Card>();
	private Map<String, Card> weaponDeck = new HashMap<String, Card>();
	private Map<String, Player> players = new HashMap<String, Player>();
	
	private Set<Character> allowedDirectionSet = new HashSet<Character>(Arrays.asList('R','L','D','U'));
	
	private Scanner csvIn = null;
	private Scanner legendIn = null;
	private Scanner weaponIn = null;
	private Scanner personIn = null;
	
	private int numRows;
	private int numColumns;
	
	private Map<BoardCell, Set<BoardCell>> adjMatrix = new HashMap<BoardCell, Set<BoardCell>>();
	private HashSet<BoardCell> visited;
	
	private Solution solution = new Solution();
	
	public Solution getSolution() {
		return solution;
	}

	public void dealCards() {
		// By nature, the order will be effectively random. No need to shuffle
		List<Card> roomList = new ArrayList<Card>(roomDeck.values());
		List<Card> peopleList = new ArrayList<Card>(peopleDeck.values());
		List<Card> weaponList = new ArrayList<Card>(weaponDeck.values());
		
		// To keep track of dealt cards
		Map<String, Card> toDeal = new HashMap<String, Card>();
		
		solution.init();
		
		solution.person = peopleList.get(0).getName();
		solution.room = roomList.get(0).getName();
		solution.weapon = weaponList.get(0).getName();
		
		for (int i = 1; i < 6; i++) {
			toDeal.put(peopleList.get(i).getName(), peopleList.get(i));
			toDeal.put(roomList.get(i).getName(), roomList.get(i));
			toDeal.put(weaponList.get(i).getName(), weaponList.get(i));
		}
		for (int i = 6; i < 9; i++) {
			toDeal.put(roomList.get(i).getName(), roomList.get(i));
		}
		
		List<Card> cardList = new ArrayList<Card>(toDeal.values());
		for (int i = 0; i < 18; i = i + 6) {
			players.get("Secretary-Susan").addCard(cardList.get(i));
			players.get("Garbageman-Greg").addCard(cardList.get(i + 1));
			players.get("Librarian-Lucy").addCard(cardList.get(i + 2));
			players.get("Congressman-Chris").addCard(cardList.get(i + 3));
			players.get("Robot-AI").addCard(cardList.get(i + 4));
			players.get("G-Eazy").addCard(cardList.get(i + 5));
		}
		
	}
	
	public static Board getInstance() {
		return theInstance;
	}
	
	public void setConfigFiles(String csvBoard, String legendfile) {
		this.boardConfigFile = csvBoard;
		this.roomConfigFile = legendfile;
		
		try {
			csvIn = new Scanner(new FileReader(boardConfigFile));
			legendIn = new Scanner(new FileReader(roomConfigFile));
		} catch (FileNotFoundException e) {
			System.err.println("FileNotFoundException" + e.getMessage());
			e.printStackTrace();
		}
		return;
	}
	
	public void setConfigFiles(String csvBoard, String legendfile, String weaponfile, String playerfile) {
		this.boardConfigFile = csvBoard;
		this.roomConfigFile = legendfile;
		this.weaponConfigFile = weaponfile;
		this.personConfigFile = playerfile;
		
		try {
			csvIn = new Scanner(new FileReader(boardConfigFile));
			legendIn = new Scanner(new FileReader(roomConfigFile));
			weaponIn = new Scanner(new FileReader(weaponConfigFile));
			personIn = new Scanner(new FileReader(personConfigFile));
		} catch (FileNotFoundException e) {
			System.err.println("FileNotFoundException" + e.getMessage());
			e.printStackTrace();
		}
		return;
	}
	
	public void initialize() {
		deck = new HashMap<String, Card>();
		peopleDeck = new HashMap<String, Card>();
		roomDeck = new HashMap<String, Card>();
		weaponDeck = new HashMap<String, Card>();
		players = new HashMap<String, Player>();
		
		try{
			if (!personConfigFile.equals("") && !weaponConfigFile.equals("")) {
				
				this.setConfigFiles(boardConfigFile, roomConfigFile);
				this.setConfigFiles(boardConfigFile, roomConfigFile, personConfigFile, weaponConfigFile);
				
				this.loadRoomConfig();
				this.loadBoardConfig();
				this.loadWeaponConfig();
				this.loadPersonConfig();
			}
			
			else {
				this.setConfigFiles(boardConfigFile, roomConfigFile);
				
				this.loadRoomConfig();
				this.loadBoardConfig();
			}
			
			this.calcAdjacencies();
		} catch (BadConfigFormatException e) {
			System.err.println("BadConfigFormatException: " + e.getMessage());
		}
		
		return;		
	}
	
	public Map<Character, String> getLegend() {
		return rooms;
	}
	
	public int getNumRows() {
		numRows = 0;
		for(int i = 0; i < MAX_BOARD_SIZE; i++) {
			if(board[i][0] != null) {
				numRows++;
			}
		}
		return numRows;
	}
	
	public int getNumColumns() {
		numColumns = 0;
		for(int i = 0; i < MAX_BOARD_SIZE; i++) {
			if(board[0][i] != null) {
				numColumns++;
			}
		}
		return numColumns;
	}
	
	public BoardCell getCellAt(int i, int j) {
		BoardCell tmpCell = board[i][j];
		return tmpCell;
	}
	
	public void loadRoomConfig() throws BadConfigFormatException {
		rooms = new HashMap<Character,String>();
		String legendLine;
		while(legendIn.hasNextLine()) {
			legendLine = legendIn.nextLine();
			String[] splitArray = legendLine.split(", ");
			rooms.put(splitArray[0].charAt(0), splitArray[1]);
			//throws if we don't have 3 elements on a line, if the first char is a string, 
			if((splitArray.length < 3) || ((!splitArray[2].equals("Card")) && (!splitArray[2].equals("Other"))) || (splitArray[0].length() > 1)) {
				throw new BadConfigFormatException("Incorrect Legend File Format!");
			}
			if (splitArray[2].equals("Card")) {
				Card card = new Card(splitArray[1], CardType.ROOM);
				deck.put(splitArray[1], card);
				roomDeck.put(splitArray[1], card);
			}
		}
		return;
	}
	
	public void loadBoardConfig() throws BadConfigFormatException {
		int checkCols = 0;
		boolean checkColSwitch = true;
		int iCounter = 0;
		board = new BoardCell[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
		while(csvIn.hasNextLine()) {
			String csvLine = csvIn.nextLine();
			String[] splitArray = csvLine.split(",");
			if(checkColSwitch) {
				checkCols = splitArray.length;
				checkColSwitch = false;
			}
			if(checkCols != splitArray.length) {
				throw new BadConfigFormatException("Columns do not match!");
			}
			for(int i = 0; i < splitArray.length; i++) {
				board[iCounter][i] = new BoardCell(iCounter, i);
				if(!rooms.containsKey(splitArray[i].charAt(0))) {
					throw new BadConfigFormatException("Referring to room not in config file!");
				}
				board[iCounter][i].setInitial(splitArray[i].charAt(0));
				if((splitArray[i].length() > 1) && (allowedDirectionSet.contains(splitArray[i].charAt(1)))) {
					board[iCounter][i].isDoorway = true;
					if(splitArray[i].charAt(1) == 'R') {
						board[iCounter][i].setDoorDir(DoorDirection.RIGHT);
					} else if(splitArray[i].charAt(1) == 'L') {
						board[iCounter][i].setDoorDir(DoorDirection.LEFT);
					} else if(splitArray[i].charAt(1) == 'U') {
						board[iCounter][i].setDoorDir(DoorDirection.UP);
					} else if(splitArray[i].charAt(1) == 'D') {
						board[iCounter][i].setDoorDir(DoorDirection.DOWN);
					}
				}
			}
			iCounter++;
		}
		return;
	}
	
	public void loadPersonConfig() throws BadConfigFormatException {
		int i = 0;
		while(personIn.hasNextLine()) {
			i++;
			String personLine = personIn.nextLine();
			if (i < 6) {
				Player player = new ComputerPlayer(personLine);
				players.put(personLine, player);
			} else if (i == 6) {
				Player player = new HumanPlayer(personLine);
				players.put(personLine, player);
			} else {
				throw new BadConfigFormatException("Too many players!");
			}
			Card card = new Card(personLine, CardType.PERSON);
			deck.put(personLine, card);
			peopleDeck.put(personLine, card);
		}
	}
	
	public void loadWeaponConfig() throws BadConfigFormatException {
		int i = 0;
		while(weaponIn.hasNextLine()) {
			i++;
			if (i <= 6) {
				String weaponLine = weaponIn.nextLine();
				Card card = new Card(weaponLine, CardType.WEAPON);
				deck.put(weaponLine, card);
				weaponDeck.put(weaponLine, card);
			} else {
				throw new BadConfigFormatException("Too many weapons!");
			}
		}
	}

	public Set<BoardCell> getTargets() {
		return targets;
	}

	public void calcTargets(int i, int j, int k) {
		visited = new HashSet<BoardCell>();
		targets = new HashSet<BoardCell>();
		visited.add(board[i][j]);
		findAllTargets(board[i][j], k);
		return;
	}
	
	public void findAllTargets(BoardCell startCell, int pathLength) {
		for(BoardCell b : adjMatrix.get(startCell)) {
			if(b.isDoorway() && !visited.contains(b)) {
				if(!targets.contains(b)) {
					targets.add(b);
				}
			}
			if(visited.contains(b)) {
				continue;
			} else {
				visited.add(b);
				if(pathLength == 1) {
					if(!targets.contains(b)) {
						targets.add(b);
					}
				} else {
					findAllTargets(b, pathLength-1);
				}
				visited.remove(b);
			}
		}
	}
	
	public Set<BoardCell> getAdjList(int i, int j) {
		return adjMatrix.get(board[i][j]);
	}
	
	public Map<BoardCell, Set<BoardCell>> calcAdjacencies() {
		for(int i = 0; i < this.getNumRows(); i++) {
			for(int j = 0; j < this.getNumColumns(); j++) {
				Set<BoardCell> tmp = new HashSet<BoardCell>();
				if(board[i][j].getInitial() == 'W') {
					if((i - 1) >= 0) {
						if((board[i-1][j].getInitial() == 'W') || (board[i-1][j].isDoorway() && board[i-1][j].getDoorDir().equals(DoorDirection.DOWN))) {
							tmp.add(board[i-1][j]);
						}
					}
					if((i + 1) < this.getNumRows()) {
						if((board[i+1][j].getInitial() == 'W') || (board[i+1][j].isDoorway() && board[i+1][j].getDoorDir().equals(DoorDirection.UP))) {
							tmp.add(board[i+1][j]);
						}
					}
					if((j - 1) >= 0) {
						if((board[i][j-1].getInitial() == 'W') || (board[i][j-1].isDoorway() && board[i][j-1].getDoorDir().equals(DoorDirection.RIGHT))) {
							tmp.add(board[i][j-1]);
						}
					}
					if((j + 1) < this.getNumColumns()) {
						if((board[i][j+1].getInitial() == 'W') || (board[i][j+1].isDoorway() && board[i][j+1].getDoorDir().equals(DoorDirection.LEFT))) {
							tmp.add(board[i][j+1]);
						}
					}
				}
				
				if(board[i][j].isDoorway()) {
					if((i - 1) >= 0) {
						if(board[i-1][j].getInitial() == 'W' && board[i][j].getDoorDir().equals(DoorDirection.UP)) {
							tmp.add(board[i-1][j]);
						}
					}
					if((i + 1) < this.getNumRows()) {
						if(board[i+1][j].getInitial() == 'W' && board[i][j].getDoorDir().equals(DoorDirection.DOWN)) {
							tmp.add(board[i+1][j]);
						}
					}
					if((j - 1) >= 0) {
						if(board[i][j-1].getInitial() == 'W' && board[i][j].getDoorDir().equals(DoorDirection.LEFT)) {
							tmp.add(board[i][j-1]);
						}
					}
					if((j + 1) < this.getNumColumns()) {
						if(board[i][j+1].getInitial() == 'W' && board[i][j].getDoorDir().equals(DoorDirection.RIGHT)) {
							tmp.add(board[i][j+1]);
						}
					}
				}
				adjMatrix.put(board[i][j], tmp);
			}
		}
		return adjMatrix;
	}
	
	public Map<String, Card> getDeck() {
		return deck;
	}
	
	public Map<String, Player> getPlayers() {
		return players;
	}
	
}
