package clueGame;

public enum CardType {
	PERSON, WEAPON, ROOM;
}
