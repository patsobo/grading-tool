package clueGame;

public class BoardCell {
	private int row;
	private int column;
	private char initial;
	public boolean isDoorway;
	
	//TODO finish implementing the doorDir
	private DoorDirection doorDir;
	
	public BoardCell() {
		//default
	}
	
	public BoardCell(int i, int j) {
		row = i;
		column = j;
	}
	
	public int getRow() {
		return row;
	}
	
	public void setRow(int row) {
		this.row = row;
	}
	
	public int getColumn() {
		return column;
	}
	
	public void setColumn(int column) {
		this.column = column;
	}
	
	public boolean isDoorway() {
		return isDoorway;
	}
	
	public DoorDirection getDoorDirection() {
		return doorDir;
	}
	
	public char getInitial() {
		return initial;
	}
	
	public void setInitial(char initial) {
		this.initial = initial;
	}
	
	public DoorDirection getDoorDir() {
		return doorDir;
	}
	
	public void setDoorDir(DoorDirection doorDir) {
		this.doorDir = doorDir;
	}
	
}

