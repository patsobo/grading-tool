package clueGame;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Player {
	private String playerName;
	private int row;
	private int column;
	private Color color;
	
	private List<Card> myCards = new ArrayList<Card>();
	
	public Player(String playerName) {
		this.playerName = playerName;
	}
	
	public Card disproveSuggestion(Solution suggestion) {
		return null;
	}
	
	public String getName() {
		return playerName;
	}
	
	public List<Card> getCards() {
		return myCards;
	}
	
	public void addCard(Card card) {
		myCards.add(card);
	}
}
