package clueGame;

public class BadConfigFormatException extends RuntimeException{
	//add class that takes in string to super
	public BadConfigFormatException() {
		super();
	}
	
	public BadConfigFormatException(String s) {
		super(s);
	}
}
