package clueGame;

public class Card {
	private String cardName;
	private CardType type;
	
	public Card() {
		cardName = "";
		type = CardType.PERSON;
	}
	
	public Card(String name, CardType type) {
		cardName = name;
		this.type = type;
	}
	
	public boolean equals(Card card) {
		if (card == null) return false;
		return (card.type == type && cardName.equals(card.getName()));
	}
	
	public String getName() {
		return cardName;
	}
}
