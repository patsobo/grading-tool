package clueGame;

public class HumanPlayer extends Player{
	public HumanPlayer(String playerName) {
		super(playerName);
	}
	
}
