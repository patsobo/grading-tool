package clueGame;

public enum DoorDirection {
	RIGHT, DOWN, LEFT, UP, NONE

}
