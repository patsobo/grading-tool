package clueGame;

public class Solution {
	public String person = null;
	public String room = null;
	public String weapon = null;
	
	public void init() {
		person = new String();
		room = new String();
		weapon = new String();
	}
}
