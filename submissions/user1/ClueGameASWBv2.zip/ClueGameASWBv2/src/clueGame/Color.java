package clueGame;

public enum Color {
	BLUE, RED, GREEN, BLACK, YELLOW, PURPLE, ORANGE, WHITE;
}
