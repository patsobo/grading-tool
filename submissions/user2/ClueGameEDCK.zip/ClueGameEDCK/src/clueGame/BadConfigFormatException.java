package clueGame;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class BadConfigFormatException extends Exception{

	public BadConfigFormatException() {
		super("The file is not in the correct format.");
	}
	public BadConfigFormatException(String message){
		super(message);
		PrintWriter out;
		try {
			out = new PrintWriter("logfile.txt");
			out.println(message);
		} catch (FileNotFoundException e) {
			System.out.println("Cannot find output log file");
					}
		
	}
	

}
