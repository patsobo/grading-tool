package clueGame;

public class BoardCell {
	private int row;
	private int column;
	private char initial;
	private DoorDirection direction;
	
	
	public BoardCell(int row, int column, char initial) {
		super();
		this.row = row;
		this.column = column;
		this.initial = initial;
	}
	
	
	
	public BoardCell(int row, int column, char initial, DoorDirection direction) {
		super();
		this.row = row;
		this.column = column;
		this.initial = initial;
		this.direction = direction;
	}



	public boolean isWalkway() {
		if (initial == 'W') {
			return true;
		}
		else {
			return false;
		}
	}
		
	public boolean isRoom() {
		if (isWalkway()) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean isDoorway(){
		if (direction == DoorDirection.NONE) {
			return false;
		}
		else {
			return true;
		}
	}
	public DoorDirection getDoorDirection(){
		return direction;
	}
	public char getInitial(){
		return initial;
	}

}
