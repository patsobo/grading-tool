package clueGame;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Board {
	private int numRows;
	private int numColumns;
	public static int MAX_BOARD_SIZE = 50;
	private BoardCell [][] board;
	private Map<Character, String> rooms;
	private Map<BoardCell, Set<BoardCell>> adjMatrix;
	private Set<BoardCell> targets;
	private String boardConfigFile;
	private String roomConfigFile;
	// variable used for singleton pattern
	private static Board theInstance = new Board();
	// ctor is private to ensure only one can be created
	private Board() {}
	// this method returns the only Board
	public static Board getInstance() {
		return theInstance;
	}
	public void initialize(){
		//rooms =  new HashMap<Character, String>();
		adjMatrix = new HashMap<BoardCell, Set<BoardCell>>();
		targets = new HashSet<BoardCell>();
		//board = new BoardCell[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
		try{
			loadRoomConfig();
		}catch(BadConfigFormatException e){
			System.out.println(e.getLocalizedMessage());
		}
		try{
			loadBoardConfig();
		}catch(BadConfigFormatException e){
			System.out.println("load board config error"); 
		}
		
	}
	public void setConfigFiles(String boardFile, String legendFile){
		boardConfigFile = boardFile;
		roomConfigFile = legendFile;
		
	}
	
	public void loadRoomConfig() throws BadConfigFormatException {
		rooms =  new HashMap<Character, String>();
		try{
			FileReader reader = new FileReader("data/" + roomConfigFile);
			//FileReader reader = new FileReader("data/CR_ClueLegend.txt");
			Scanner in = new Scanner(reader);
			while(in.hasNextLine()){
				String line = in.nextLine();
				String [] parts = line.split(", ");
				String roomName = parts[1];
				String symbol = parts[0];
				//System.out.println(parts[2]);
				/*if(!parts[2].equals("Other") && !parts[2].equals("Card")){
					throw new BadConfigFormatException( roomName + " is not a card or other");
				}
				else{
					char roomSymbol = symbol.charAt(0);
					rooms.put(roomSymbol, roomName);				
				}
				*/
				
				if(parts[2].equals("Other") || parts[2].equals("Card")){
					char roomSymbol = symbol.charAt(0);
					rooms.put(roomSymbol, roomName);	
					
				}
				else{
					throw new BadConfigFormatException( roomName + " is not a card or other");			
				}
			}
			in.close();
		}catch(FileNotFoundException e){
			System.out.println("RoomConfigFile not found");
		}
	}
	
	public void loadBoardConfig() throws BadConfigFormatException{
		board = new BoardCell[MAX_BOARD_SIZE][MAX_BOARD_SIZE];
		try{
			FileReader reader = new FileReader("data/" + boardConfigFile);
			Scanner in = new Scanner(reader);
			int lineNum = 0; 
			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] parts = line.split(",");
				
				if (numColumns < parts.length) {
					numColumns = parts.length;
				}
				
				if(numColumns > parts.length) {
					
					throw new BadConfigFormatException("Columns do not contain the correct number of characters.");
				}
				else{
					for (int i = 0; i< parts.length; i++) {
						String current = parts[i];
						char currentSymbol = current.charAt(0);
						if(!(rooms.containsKey(currentSymbol))){
							throw new BadConfigFormatException(currentSymbol + " does not exist in legend");
						}
						else{
							if (current.length() > 1) {
								if(current.charAt(1) == 'U') {
									BoardCell cell = new BoardCell (lineNum, i, currentSymbol, DoorDirection.UP);
									board[lineNum][i] = cell;
								}
								if(current.charAt(1) == 'L') {
									BoardCell cell = new BoardCell (lineNum, i, currentSymbol, DoorDirection.LEFT);
									board[lineNum][i] = cell;
								}
								if(current.charAt(1) == 'D') {
									BoardCell cell = new BoardCell (lineNum, i, currentSymbol, DoorDirection.DOWN);
									board[lineNum][i] = cell;
								}
								if(current.charAt(1) == 'R') {
									BoardCell cell = new BoardCell (lineNum, i, currentSymbol, DoorDirection.RIGHT);
									board[lineNum][i] = cell;
								}
								
								//If there is no direction
								if(current.charAt(1) == 'N') {
									BoardCell cell = new BoardCell(lineNum,i,currentSymbol,DoorDirection.NONE);
									board[lineNum][i] = cell;
								}
							}
							
							else {
								BoardCell cell = new BoardCell(lineNum,i,currentSymbol,DoorDirection.NONE);
								board[lineNum][i] = cell;
							}
						}
					}
					lineNum++;
				}
			}
		in.close();
			//Setting the number of rows
			numRows = lineNum;
		}catch(FileNotFoundException e){
			System.out.println("BoardConfigFile not found");
		}

	}
	public void calcAdjacencies(){
		
	}
	public void calcTargets(BoardCell cell, int pathLength){
		
	}
	public Map<Character, String> getLegend(){
		return rooms;
	}
	public int getNumRows(){
		return numRows;
	}
	public int getNumColumns(){
		return numColumns;
	}
	public BoardCell getCellAt(int a, int b){
		return board[a][b];
	}

}
