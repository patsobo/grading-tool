package experiments;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class IntBoard {
	private Map<BoardCell, Set<BoardCell>> adjacentCells;
	private Set<BoardCell> visited;
	private Set<BoardCell> targets;
	private BoardCell[][] grid;
	private int ROWS =4;
	private int COLUMNS =4;
	public IntBoard() {
		super();
		adjacentCells = new HashMap<BoardCell, Set<BoardCell>>();
		visited = new HashSet<BoardCell>();
		targets = new HashSet<BoardCell>();
		grid = new BoardCell[ROWS][COLUMNS];
		for (int i = 0; i < ROWS; i ++) {
			for (int j = 0; j < COLUMNS; j++) {
				BoardCell cell = new BoardCell(i,j);
				grid[i][j] = cell;
			}
		}
	}
	public void calcAdjacencies(){
		
		for(int i = 0; i < ROWS; i++)
		{
			for(int j = 0; j < COLUMNS; j++)
			{
				Set<BoardCell> adj = new HashSet<BoardCell>();
				if(i-1 >= 0)
				{
					adj.add(grid[i-1][j]);
					//System.out.println("Cell A" + cellA.toString());
				}
				if(i+1 < ROWS)
				{
					adj.add(grid[i+1][j]);
				}
				if(j-1 >= 0)
				{
					adj.add(grid[i][j-1]);
				}
				if(j+1 < COLUMNS)
				{
					adj.add(grid[i][j+1]);
				}
				
				adjacentCells.put(grid[i][j], adj);
				//System.out.println(adjacentCells.get(cell).toString());
				//System.out.println(cell.toString()); 
			}
		}
	
	}
	
	public void calcTargets(BoardCell startCell, int pathLength){
		Set<BoardCell> adjCell = getAdjList(startCell);
		for(BoardCell adj: adjCell){
			if(!(visited.contains(adj)))
			{
				visited.add(adj);
				if(pathLength == 1){
					targets.add(adj);
					
				}
				else{
					calcTargets(adj, pathLength-1);
				}
			}
			visited.remove(adj);
		}
		
	}
	public Set<BoardCell> getTargets(BoardCell cell, int pathLength){
		visited.add(cell);
		calcTargets(cell, pathLength);
		targets.remove(cell);
		return targets;
	}
	public Set<BoardCell> getAdjList(BoardCell cell)
	{
		return adjacentCells.get(cell);
	}
	
	public BoardCell getCell(int row, int column) {
		return grid[row][column];
	}
	
}
