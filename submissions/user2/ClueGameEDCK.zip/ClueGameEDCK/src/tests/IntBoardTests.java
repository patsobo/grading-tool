package tests;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import experiments.BoardCell;
import experiments.IntBoard;

public class IntBoardTests {
	private IntBoard board;
	@Before
	public void setUp(){
		board = new IntBoard();
		board.calcAdjacencies();
		System.out.println("in @Before");
	}
	@Test
	public void testTopLeftCorner() {

		System.out.println("test");	
		BoardCell cell = board.getCell(0,0);
		Set<BoardCell> testList = new HashSet<BoardCell>();
		testList = board.getAdjList(cell);
		System.out.println(testList.size());		
		assertEquals(2, testList.size());
		System.out.println("test");		
		
	}
	@Test
	public void testBottomRightCorner() {
		BoardCell cell = board.getCell(3,3);
		Set<BoardCell> testList = board.getAdjList(cell);
		BoardCell left = board.getCell(3,2);
		BoardCell up = board.getCell(2,3);
		assertTrue(testList.contains(left));
		assertTrue(testList.contains(up));
		assertEquals(2, testList.size());
	}
	@Test
	public void testRightEdge() {
		BoardCell cell = board.getCell(1,3);
		Set<BoardCell> testList = board.getAdjList(cell);
		BoardCell left = board.getCell(1,2);
		BoardCell up = board.getCell(0,3);
		BoardCell down = board.getCell(2,3);
		assertTrue(testList.contains(left));
		assertTrue(testList.contains(up));
		assertTrue(testList.contains(down));
		assertEquals(3, testList.size());
	}	
	@Test
	public void testLeftEdge() {
		BoardCell cell = board.getCell(2,0);
		Set<BoardCell> testList = board.getAdjList(cell);
		BoardCell right = board.getCell(2,1);
		BoardCell up = board.getCell(1,0);
		BoardCell down = board.getCell(3,0);
		assertTrue(testList.contains(right));
		assertTrue(testList.contains(up));
		assertTrue(testList.contains(down));
		assertEquals(3, testList.size());
	}
	@Test
	public void testColumnMiddle() {
		BoardCell cell = board.getCell(1,1);
		Set<BoardCell> testList = board.getAdjList(cell);
		BoardCell right = board.getCell(1,2);
		BoardCell up = board.getCell(0,1);
		BoardCell down = board.getCell(2,1);
		BoardCell left = board.getCell(1,0);
		assertTrue(testList.contains(right));
		assertTrue(testList.contains(up));
		assertTrue(testList.contains(down));
		assertTrue(testList.contains(left));
		assertEquals(4, testList.size());
	}
	@Test
	public void testColumnMiddleLast() {
		BoardCell cell = board.getCell(2,2);
		Set<BoardCell> testList = board.getAdjList(cell);
		BoardCell right = board.getCell(2,3);
		BoardCell up = board.getCell(1,2);
		BoardCell down = board.getCell(3,2);
		BoardCell left = board.getCell(2,1);
		assertTrue(testList.contains(right));
		assertTrue(testList.contains(up));
		assertTrue(testList.contains(down));
		assertTrue(testList.contains(left));
		assertEquals(4, testList.size());
	}
	@Test
	public void testTargets0_2(){
		BoardCell cell = board.getCell(0,0);
		//board.calcTargets(cell, 2);
		Set<BoardCell>  targets = board.getTargets(cell, 2);
		assertEquals(3, targets.size());
		
		BoardCell cellA = board.getCell(0,2);
		BoardCell cellB = board.getCell(1,1);
		BoardCell cellC = board.getCell(2,0);
		assertTrue(targets.contains(cellA));
		assertTrue(targets.contains(cellB));
		assertTrue(targets.contains(cellC));
		 
		
	}
	
	@Test
	public void testTargets0_1(){
		BoardCell cell = board.getCell(0,0);
		Set<BoardCell>  targets = board.getTargets(cell, 1);
		assertEquals(2, targets.size());
		
		BoardCell cellA = board.getCell(0,1);
		BoardCell cellB = board.getCell(1,0);

		assertTrue(targets.contains(cellA));
		assertTrue(targets.contains(cellB));
		
	}
	
	@Test
	public void testTargets5_1(){
		BoardCell cell = board.getCell(1,1);
		Set<BoardCell> targets = board.getTargets(cell, 1);
		assertEquals(4, targets.size());
		
		BoardCell cellA = board.getCell(0,1);
		BoardCell cellB = board.getCell(1,0);
		BoardCell cellC = board.getCell(1,2);
		BoardCell cellD = board.getCell(2,1);
		
		assertTrue(targets.contains(cellA));
		assertTrue(targets.contains(cellB));
		assertTrue(targets.contains(cellC));
		assertTrue(targets.contains(cellD));
		
	}
	
	@Test
	public void testTargets5_2(){
		BoardCell cell = board.getCell(1,1);
		Set<BoardCell>  targets = board.getTargets(cell, 2);
		assertEquals(6, targets.size());
		
		BoardCell cellA = board.getCell(0,0);
		BoardCell cellB = board.getCell(0,2);
		BoardCell cellC = board.getCell(1,3);
		BoardCell cellD = board.getCell(2,0);
		BoardCell cellE = board.getCell(3,1);
		BoardCell cellF = board.getCell(2,2);
		
		assertTrue(targets.contains(cellA));
		assertTrue(targets.contains(cellB));
		assertTrue(targets.contains(cellC));
		assertTrue(targets.contains(cellD));
		assertTrue(targets.contains(cellE));
		assertTrue(targets.contains(cellF));
	}
	
	@Test
	public void testTargets5_3(){
		BoardCell cell = board.getCell(1,1);
		Set<BoardCell>  targets = board.getTargets(cell, 3);
		assertEquals(8, targets.size());
		
		BoardCell cellA = board.getCell(1,0);
		BoardCell cellB = board.getCell(1,2);
		BoardCell cellC = board.getCell(0,3);
		BoardCell cellD = board.getCell(2,3);
		BoardCell cellE = board.getCell(3,2);
		BoardCell cellF = board.getCell(3,0);
		BoardCell cellG = board.getCell(2,1);
		BoardCell cellH = board.getCell(0,1);
		
		assertTrue(targets.contains(cellA));
		assertTrue(targets.contains(cellB));
		assertTrue(targets.contains(cellC));
		assertTrue(targets.contains(cellD));
		assertTrue(targets.contains(cellE));
		assertTrue(targets.contains(cellF));
		assertTrue(targets.contains(cellG));
		assertTrue(targets.contains(cellH));
	}
	
	@Test
	public void testTargets0_4(){
		BoardCell cell = board.getCell(0,0);
		Set<BoardCell>  targets = board.getTargets(cell, 4);
		assertEquals(6, targets.size());
		
		BoardCell cellA = board.getCell(1,3);
		BoardCell cellB = board.getCell(3,1);
		BoardCell cellC = board.getCell(1,1);
		BoardCell cellD = board.getCell(2,2);
		BoardCell cellE = board.getCell(0,2);
		BoardCell cellF = board.getCell(2,0);
		
		
		assertTrue(targets.contains(cellA));
		assertTrue(targets.contains(cellB));
		assertTrue(targets.contains(cellC));
		assertTrue(targets.contains(cellD));
		assertTrue(targets.contains(cellE));
		assertTrue(targets.contains(cellF));
		
	}


}
