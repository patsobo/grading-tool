package tests;

import static org.junit.Assert.*;

import java.awt.Color;
import java.util.*;

import org.junit.*;

import clueGame.*;

public class GameSetupTests {

    private static Board board;

    @BeforeClass
    public static void setUp() {
        // Get the Board singleton instance.
        board = Board.getInstance();

        // Set the filenames for the configuration files.
        board.setConfigFiles("board_layout_JEZB.csv", "legend.txt", "people.txt", "weapons.txt");

        // Initialize the board with the configuration files.
        board.initialize();
    }

    // Test the players.
    @Test
    public void testPlayers() {
        ArrayList<Player> players = board.getPlayers();

        // Test number of people.
        assertEquals(6, players.size());

        // Test a few samples to ensure that they are loaded correctly
        // (including location).
        Player arnold = board.getPlayer("Arnold Schwarzenegger");
        assertTrue(arnold != null);
        assertEquals(0, arnold.getRow());
        assertEquals(3, arnold.getCol());
        assertEquals(Color.RED, arnold.getColor());

        Player amy = board.getPlayer("Amy Winehouse");
        assertTrue(amy != null);
        assertEquals(6, amy.getRow());
        assertEquals(22, amy.getCol());
        assertEquals(Color.ORANGE, amy.getColor());

        Player bill = board.getPlayer("Bill Nye");
        assertTrue(bill != null);
        assertEquals(17, bill.getRow());
        assertEquals(7, bill.getCol());
        assertEquals(Color.WHITE, bill.getColor());

        // Test to ensure that only one human player exists.
        int numHumanPlayers = 0;
        for (Player p : players) {
            if (p instanceof HumanPlayer)
                numHumanPlayers++;
        }

        assertEquals(1, numHumanPlayers);
    }

    // Test the people cards.
    @Test
    public void testPeople() {
        // Test number of people.
        assertEquals(6, board.getPeople().size());

        // Test a few samples to ensure that they are loaded correctly
        // (including location).
        Card arnold = board.getCard("Arnold Schwarzenegger");
        assertTrue(arnold != null);
        assertTrue(arnold.getCardType() == Card.CardType.PERSON);

        Card amy = board.getCard("Amy Winehouse");
        assertTrue(amy != null);
        assertTrue(amy.getCardType() == Card.CardType.PERSON);

        Card bill = board.getCard("Bill Nye");
        assertTrue(bill != null);
        assertTrue(bill.getCardType() == Card.CardType.PERSON);
    }

    // Test the weapon cards.
    @Test
    public void testWeapons() {
        // Test number of weapons.
        assertEquals(6, board.getWeapons().size());

        // Test a few samples to ensure that they are loaded.
        Card katana = board.getCard("Katana");
        assertTrue(katana != null);
        assertTrue(katana.getCardType() == Card.CardType.WEAPON);

        Card laser = board.getCard("Laser");
        assertTrue(laser != null);
        assertTrue(laser.getCardType() == Card.CardType.WEAPON);

        Card napalm = board.getCard("Napalm");
        assertTrue(napalm != null);
        assertTrue(napalm.getCardType() == Card.CardType.WEAPON);
    }

    // Test the room cards.
    @Test
    public void testRooms() {
        // Test number of rooms (doesn't include closet/Kafadar).
        assertEquals(9, board.getRooms().size());

        // Test a few samples to ensure that they are loaded.
        // CTLM
        Card ctlm = board.getCard("CTLM");
        assertTrue(ctlm != null);
        assertTrue(ctlm.getCardType() == Card.CardType.ROOM);

        // EPICS Annex
        Card epics = board.getCard("EPICS Annex");
        assertTrue(epics != null);
        assertTrue(epics.getCardType() == Card.CardType.ROOM);

        // Rec Center
        Card recCenter = board.getCard("Rec Center");
        assertTrue(recCenter != null);
        assertTrue(recCenter.getCardType() == Card.CardType.ROOM);

        // Ensure that walkways and closet are not cards.
        Card walkway = board.getCard("Walkway");
        assertTrue(walkway == null);

        Card closet = board.getCard("Closet");
        assertTrue(closet == null);
    }

    // Test dealing the cards.
    @Test
    public void testDeal() {
        Solution solution = board.getSolution();

        // Test that the total number of cards is correct.
        assertEquals(21, board.getCards().size());

        // Test that the number of cards / player is correct for a few players.
        assertEquals(3, board.getPlayer("Amy Winehouse").getPlayerCards().size());
        assertEquals(3, board.getPlayer("Donald Duck").getPlayerCards().size());
        assertEquals(3, board.getPlayer("Bill Nye").getPlayerCards().size());

        // Ensure that the same card is not dealt to multiple players or
        // included in the solution and in a player's hand.
        Set<Card> dealtCards = new HashSet<Card>();
        dealtCards.add(solution.person);
        dealtCards.add(solution.weapon);
        dealtCards.add(solution.room);

        for (Player p : board.getPlayers()) {
            for (Card c : dealtCards) {
                assertFalse(p.getPlayerCards().contains(c));
                dealtCards.add(c);
            }
        }
    }

    // Test that the cards were shuffled.
    @Test
    public void testShuffle() {
        Solution solution = board.getSolution();

        // When the cards are shuffled, most likely the top card of at least one
        // card type will not be the same as before. We aren't going to optimize
        // for the situation where they could end up being the top cards.
        Card katana = board.getCard("Katana");
        Card arnold = board.getCard("Arnold Schwarzenegger");
        Card ctlm = board.getCard("CTLM");

        assertFalse(solution.contains(katana) && solution.contains(arnold) && solution.contains(ctlm));

        // The cards are loaded in from each configuration file. This will
        // result in a cards vector which will have a bunch of cards of the same
        // type right next to each other (with only two card type changes). Test
        // to ensure the cards have been shuffled enough that there are fewer
        // than 18 consecutive cards of the same type. It is technically
        // possible for this test to fail if the shuffle method shuffles the
        // cards back into an order which only has a few type changes, but we
        // are not going to optimize for this (very) slight possibility.
        int consecutiveOfSameType = 0;
        ArrayList<Card> cards = board.getCards();

        for (int i = 1; i < cards.size(); i++) {
            if (cards.get(i - 1).getCardType().equals(cards.get(i).getCardType()))
                consecutiveOfSameType++;
        }

        assertTrue(consecutiveOfSameType < 18);
    }
}
