package tests;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.*;

public class ConfigLoadTests {
    // Constants for size of legend and board.
    public static final int LEGEND_SIZE = 11;
    public static final int NUM_ROWS = 22;
    public static final int NUM_COLUMNS = 23;
    public static final int NUM_DOORS = 20;

    private static Board board;

    @BeforeClass
    public static void setUp() {
        // Get the Board singleton instance
        board = Board.getInstance();

        // Set the filenames for the configuration files
        board.setConfigFiles("board_layout_JEZB.csv", "legend.txt", "people.txt", "weapons.txt");

        // Initialize the board with the configuration files
        board.initialize();
    }

    // Ensure the legend file is loaded correctly.
    @Test
    public void testLegend() {
        // Get the map of initial => room
        Map<Character, String> legend = board.getLegend();

        // Ensure we read the correct number of rooms
        assertEquals(LEGEND_SIZE, legend.size());

        // To ensure data is correctly loaded, test retrieving a few rooms
        // from the hash, including the first and last in the file and a few
        // others
        assertEquals("CTLM", legend.get('C'));
        assertEquals("Brown Building", legend.get('B'));
        assertEquals("EPICS Annex", legend.get('A'));
        assertEquals("Rec Center", legend.get('R'));
        assertEquals("Walkway", legend.get('W'));
    }

    // Ensure the correct number of rows/columns have been read
    @Test
    public void testBoardDimensions() {
        // Ensure we have the proper number of rows and columns
        assertEquals(NUM_ROWS, board.getNumRows());
        assertEquals(NUM_COLUMNS, board.getNumColumns());
    }

    // Verify at least one doorway in each direction. Also verify cells that
    // don't contain doorways return false for isDoorway.
    @Test
    public void testDoorways() {
        BoardCell door;

        // EPICS Annex door
        door = board.getCellAt(1, 0);
        assertTrue(door.isDoorway());
        assertEquals(DoorDirection.DOWN, door.getDoorDirection());

        // Brown Building Right door
        door = board.getCellAt(1, 11);
        assertTrue(door.isDoorway());
        assertEquals(DoorDirection.RIGHT, door.getDoorDirection());

        // CTLM Upper Door
        door = board.getCellAt(3, 1);
        assertTrue(door.isDoorway());
        assertEquals(DoorDirection.UP, door.getDoorDirection());

        // Rec Center Left Door
        door = board.getCellAt(17, 19);
        assertTrue(door.isDoorway());
        assertEquals(DoorDirection.LEFT, door.getDoorDirection());

        door = board.getCellAt(4, 6);
        assertTrue(!door.isDoorway());

        door = board.getCellAt(12, 11);
        assertTrue(!door.isDoorway());
    }

    // Test that the correct number of doors have been loaded
    @Test
    public void testNumDoorways() {
        int numDoors = 0;
        for (int i = 0; i < board.getNumRows(); i++) {
            for (int j = 0; j < board.getNumColumns(); j++) {
                if (board.getCellAt(i, j).isDoorway())
                    numDoors++;
            }
        }

        assertEquals(NUM_DOORS, numDoors);
    }

    // Test some of the cells to ensure they have the correct initial
    @Test
    public void testInitials() {
        // The squares adjacent to the weird walkway on column 8.
        assertEquals('B', board.getCellAt(1, 7).getInitial());
        assertEquals('B', board.getCellAt(1, 9).getInitial());

        // Square on Left Boundary of Fieldhouse
        assertEquals('F', board.getCellAt(2, 15).getInitial());

        // A square in Kafadar Commons
        assertEquals('X', board.getCellAt(12, 11).getInitial());

        // A walkway
        assertEquals('W', board.getCellAt(13, 6).getInitial());

        // A square on right boundary of Marquez
        assertEquals('M', board.getCellAt(19, 13).getInitial());
    }
}
