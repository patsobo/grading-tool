package tests;

/*
 * This program tests that config files are loaded properly.
 */

// Doing a static import allows me to write assertEquals rather than
// Assert.assertEquals
import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.DoorDirection;

public class FileInitTests {
	// Constants
	public static final int LEGEND_SIZE = 11;
	public static final int NUM_ROWS = 23;
	public static final int NUM_COLUMNS = 24;

	private static Board board;

	@BeforeClass
	public static void setUp() {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("ClueLayout.csv", "ClueLegend.txt", "people.txt", "weapons.txt");
		// Initialize will load BOTH config files
		board.initialize();
	}
	@Test
	public void testRooms() {
		// Get the map of initial => room
		Map<Character, String> legend = board.getLegend();
		// correct number of rooms
		assertEquals(LEGEND_SIZE, legend.size());

		assertEquals("Captain's Quarters", legend.get('C'));
		assertEquals("Bridge", legend.get('B'));
		assertEquals("Transporters", legend.get('T'));
		assertEquals("Escape Pods", legend.get('O'));
		assertEquals("Weapons Bay", legend.get('P'));
		assertEquals("Med Bay", legend.get('M'));
		assertEquals("Dining Area", legend.get('D'));
		assertEquals("Turbo Lift", legend.get('X'));
		assertEquals("Forward Guns", legend.get('G'));
		assertEquals("Infrastructure", legend.get('L'));
		assertEquals("Hallway", legend.get('W'));
	}

	@Test
	public void testDimensions() {
		// Ensure we have the proper number of rows and columns
		assertEquals(NUM_ROWS, board.getNumRows());
		assertEquals(NUM_COLUMNS, board.getNumColumns());
	}

	// Test a doorway in each direction (RIGHT/LEFT/UP/DOWN), plus
	// two cells that are not a doorway.
	// These cells are white on the planning spreadsheet
	@Test
	public void testDoorDirections() {
		BoardCell room = board.getCellAt(9, 5);
		assertTrue(room.isDoorway());
		assertEquals(DoorDirection.RIGHT, room.getDoorDirection());
		room = board.getCellAt(3, 6);
		assertTrue(room.isDoorway());
		assertEquals(DoorDirection.DOWN, room.getDoorDirection());
		room = board.getCellAt(2, 17);
		assertTrue(room.isDoorway());
		assertEquals(DoorDirection.LEFT, room.getDoorDirection());
		room = board.getCellAt(16, 10);
		assertTrue(room.isDoorway());
		assertEquals(DoorDirection.UP, room.getDoorDirection());
		// Test that room pieces that aren't doors know it
		room = board.getCellAt(12, 12);
		assertFalse(room.isDoorway());
		// Test that walkways are not doors
		BoardCell cell = board.getCellAt(7, 7);
		assertFalse(cell.isDoorway());

	}

	// Test that we have the correct number of doors
	@Test
	public void testNumberOfDoorways()
	{
		int doors = 0;
		for (int row=0; row<board.getNumRows(); row++)
			for (int col=0; col<board.getNumColumns(); col++) {
				BoardCell cell = board.getCellAt(row, col);
				if (cell.isDoorway())
					doors++;
			}
		Assert.assertEquals(15, doors);
	}

	// Test a few room cells to ensure the room initial is correct.
	@Test
	public void testRoomInitials() {
		// Test corners
		assertEquals('M', board.getCellAt(0, 0).getInitial());
		assertEquals('P', board.getCellAt(0, 23).getInitial());
		assertEquals('D', board.getCellAt(22, 0).getInitial());
		assertEquals('G', board.getCellAt(22, 23).getInitial());

		// Test mid board
		assertEquals('X', board.getCellAt(11, 10).getInitial());

		// Test various rooms
		assertEquals('C', board.getCellAt(0, 11).getInitial());
		assertEquals('O', board.getCellAt(12, 4).getInitial());
		assertEquals('B', board.getCellAt(19, 12).getInitial());

		// Test a walkway
		assertEquals('W', board.getCellAt(0, 8).getInitial());
	}
}
