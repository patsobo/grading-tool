package tests;

/*
 * This program tests that adjacencies and targets are calculated correctly.
 */

import java.util.Set;

//Doing a static import allows me to write assertEquals rather than
//assertEquals
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;

import clueGame.Board;
import clueGame.BoardCell;

public class BoardAdjTargetTests {
	// We make the Board static because we can load it one time and
	// then do all the tests.
	private static Board board;
	@BeforeClass
	public static void setUp() {
		// Board is singleton, get the only instance and initialize it
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueLegend.txt", "people.txt", "weapons.txt");
		board.initialize();
	}

	// Ensure that player does not move around within room
	// These cells are ORANGE on the planning spreadsheet
	@Test
	public void testAdjacenciesInsideRooms()
	{
		// Test a corner
		Set<BoardCell> testList = board.getAdjList(0, 0);
		assertEquals(0, testList.size());
		// Test one that has walkway above
		testList = board.getAdjList(16, 12);
		assertEquals(0, testList.size());
		// Test one that has walkway left
		testList = board.getAdjList(19, 23);
		assertEquals(0, testList.size());
		// Test one that is in middle of room
		testList = board.getAdjList(11, 3);
		assertEquals(0, testList.size());
		// Test one beside a door
		testList = board.getAdjList(9, 4);
		assertEquals(0, testList.size());
		// Test one in a corner of room
		testList = board.getAdjList(22, 3);
		assertEquals(0, testList.size());
	}

	// Ensure that the adjacency list from a doorway is only the
	// walkway. NOTE: This test could be merged with door
	// direction test.
	// These tests are PURPLE on the planning spreadsheet
	@Test
	public void testAdjacencyRoomExit()
	{
		// TEST DOORWAY RIGHT
		Set<BoardCell> testList = board.getAdjList(4, 5);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(4, 6)));
		// TEST DOORWAY LEFT
		testList = board.getAdjList(3, 22);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(3, 21)));
		//TEST DOORWAY DOWN
		testList = board.getAdjList(5, 11);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(6, 11)));
		//TEST DOORWAY UP
		testList = board.getAdjList(18, 17);
		assertEquals(1, testList.size());
		assertTrue(testList.contains(board.getCellAt(17, 17)));

	}

	// Test adjacency at entrance to rooms
	// These tests are GREEN in planning spreadsheet
	@Test
	public void testAdjacencyDoorways()
	{
		// Test beside a door direction UP
		Set<BoardCell> testList = board.getAdjList(6, 13);
		assertTrue(testList.contains(board.getCellAt(6, 12)));
		assertTrue(testList.contains(board.getCellAt(6, 14)));
		assertTrue(testList.contains(board.getCellAt(5, 13)));
		assertTrue(testList.contains(board.getCellAt(7, 13)));
		assertEquals(4, testList.size());

		// Test beside a door direction RIGHT
		testList = board.getAdjList(3, 21);
		assertTrue(testList.contains(board.getCellAt(3, 22)));
		assertTrue(testList.contains(board.getCellAt(3, 20)));
		assertTrue(testList.contains(board.getCellAt(4, 21)));
		assertEquals(3, testList.size());

		// Test beside a door direction LEFT and UP
		testList = board.getAdjList(4, 6);
		assertTrue(testList.contains(board.getCellAt(4, 5)));
		assertTrue(testList.contains(board.getCellAt(4, 7)));
		assertTrue(testList.contains(board.getCellAt(3, 6)));
		assertTrue(testList.contains(board.getCellAt(5, 6)));
		assertEquals(4, testList.size());

		// Test beside a door direction DOWN
		testList = board.getAdjList(15, 14);
		assertTrue(testList.contains(board.getCellAt(15, 13)));
		assertTrue(testList.contains(board.getCellAt(15, 15)));
		assertTrue(testList.contains(board.getCellAt(14, 14)));
		assertTrue(testList.contains(board.getCellAt(16, 14)));
		assertEquals(4, testList.size());
	}

	// Test a variety of walkway scenarios
	// These tests are LIGHT PURPLE on the planning spreadsheet
	@Test
	public void testAdjacencyWalkways()
	{
		// Test surrounded by 4 walkways
		Set<BoardCell>  testList = board.getAdjList(7, 8);
		assertTrue(testList.contains(board.getCellAt(7, 9)));
		assertTrue(testList.contains(board.getCellAt(6, 8)));
		assertTrue(testList.contains(board.getCellAt(7, 7)));
		assertTrue(testList.contains(board.getCellAt(8, 8)));
		assertEquals(4, testList.size());

		// Test on top edge of board, just one walkway piece
		testList = board.getAdjList(0, 8);
		assertTrue(testList.contains(board.getCellAt(1, 8)));
		assertEquals(1, testList.size());

		// Test on left edge of board, two walkway pieces
		testList = board.getAdjList(15, 0);
		assertTrue(testList.contains(board.getCellAt(16, 0)));
		assertTrue(testList.contains(board.getCellAt(15, 1)));
		assertEquals(2, testList.size());

		// Test between two rooms, walkways up and down
		testList = board.getAdjList(4, 16);
		assertTrue(testList.contains(board.getCellAt(5, 16)));
		assertTrue(testList.contains(board.getCellAt(3, 16)));
		assertEquals(2, testList.size());

		// Test on walkway next to  door that is not in the needed
		// direction to enter
		testList = board.getAdjList(16, 9);
		assertTrue(testList.contains(board.getCellAt(15, 9)));
		assertTrue(testList.contains(board.getCellAt(17, 9)));
		assertTrue(testList.contains(board.getCellAt(16, 8)));
		assertEquals(3, testList.size());
	}


	// Tests of just walkways, 1 step, includes on edge of board
	// and beside room
	// Have already tested adjacency lists on all four edges, will
	// only test two edges here
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testTargetsOneStep() {
		board.calcTargets(18, 0, 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCellAt(17, 0)));
		assertTrue(targets.contains(board.getCellAt(18, 1)));

		board.calcTargets(7, 21, 1);
		targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCellAt(6, 21)));
		assertTrue(targets.contains(board.getCellAt(7, 20)));
	}

	// Tests of just walkways, 2 steps
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testTargetsTwoSteps() {
		board.calcTargets(16, 3, 2);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCellAt(16, 5)));
		assertTrue(targets.contains(board.getCellAt(15, 4)));
		assertTrue(targets.contains(board.getCellAt(15, 2)));
		assertTrue(targets.contains(board.getCellAt(16, 1)));

		board.calcTargets(15, 21, 2);
		targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCellAt(15, 19)));
		assertTrue(targets.contains(board.getCellAt(16, 20)));

	}

	@Test
	public void testTargetsIntoRoom()
	{
		// Two rooms are exactly 2 away
		board.calcTargets(6, 12, 2);
		Set<BoardCell> targets = board.getTargets();
		assertEquals(6, targets.size());

		assertTrue(targets.contains(board.getCellAt(6, 10)));
		assertTrue(targets.contains(board.getCellAt(7, 11)));
		assertTrue(targets.contains(board.getCellAt(7, 13)));
		assertTrue(targets.contains(board.getCellAt(6, 14)));

		//entrance
		assertTrue(targets.contains(board.getCellAt(5, 13)));
		assertTrue(targets.contains(board.getCellAt(5, 11)));

		board.calcTargets(9, 6,1);
		targets = board.getTargets();
		assertEquals(4, targets.size());

		assertTrue(targets.contains(board.getCellAt(9, 7)));
		assertTrue(targets.contains(board.getCellAt(9, 5)));
		assertTrue(targets.contains(board.getCellAt(8, 6)));
		assertTrue(targets.contains(board.getCellAt(10, 6)));
	}

	// Test getting out of a room
	// These are LIGHT BLUE on the planning spreadsheet
	@Test
	public void testRoomExit()
	{
		board.calcTargets(8, 18, 2);
		Set<BoardCell> targets= board.getTargets();

		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCellAt(7, 17)));
		assertTrue(targets.contains(board.getCellAt(6, 18)));
		assertTrue(targets.contains(board.getCellAt(7, 19)));

		board.calcTargets(14, 18, 3);
		targets= board.getTargets();
		assertEquals(5, targets.size());
		assertTrue(targets.contains(board.getCellAt(15, 16)));
		assertTrue(targets.contains(board.getCellAt(16, 17)));
		assertTrue(targets.contains(board.getCellAt(17, 18)));
		assertTrue(targets.contains(board.getCellAt(16, 19)));
		assertTrue(targets.contains(board.getCellAt(15, 20)));

	}
}