package tests;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.*;

import clueGame.*;
import clueGame.Card.CardType;

public class GameActionTests {

    private static Board board;

    @BeforeClass
    public static void setUp() {
        // Get the Board singleton instance.
        board = Board.getInstance();

        // Set the filenames for the configuration files.
        board.setConfigFiles("board_layout_JEZB.csv", "legend.txt", "people.txt", "weapons.txt");
    }

    @Before
    public void init() {
        // Initialize the board with the configuration files.
        board.initialize();
    }

    // Tests if a computer player moves to the correct position if there is a
    // room.
    @Test
    public void testTargetLocation() {
        // Do this 100 times to make sure that there are not weird issues.
        for (int i = 0; i < 100; i++) {
            // Reset the board
            this.init();

            Player player = board.getPlayer("Arnold Schwarzenegger");
            if (player instanceof ComputerPlayer) {
                board.calcTargets(player.getRow(), player.getCol(), 5);
                ComputerPlayer cplayer = (ComputerPlayer) player;
                // make sure Arnold goes into CTLM with a roll of 5
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                assertEquals(1, player.getCol());
                assertEquals(3, player.getRow());

                // make sure arnold chooses a random move with a roll of 2
                board.calcTargets(player.getRow(), player.getCol(), 2);
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
            }

            // Assert Charlie Sheen makes it into Brown with a roll of 6
            player = board.getPlayer("Charlie Sheen");
            if (player instanceof ComputerPlayer) {
                board.calcTargets(player.getRow(), player.getCol(), 6);
                ComputerPlayer cplayer = (ComputerPlayer) player;
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                assertEquals(5, player.getCol());
                assertEquals(4, player.getRow());

                // Assert Charlie Sheen makes it to a random square if no room
                board.calcTargets(player.getRow(), player.getCol(), 5);
                assertTrue(board.getTargets().contains(cplayer.pickLocation(board.getTargets())));

                // Assert Charlie Sheen does not enter the same room twice
                board.calcTargets(player.getRow(), player.getCol(), 2);
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                board.calcTargets(player.getRow(), player.getCol(), 2);
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                assertFalse((4 == cplayer.getRow()) && (5 == cplayer.getCol()));
            }

            // Assert Donald Duck makes it to the library with a roll of 5
            player = board.getPlayer("Donald Duck");
            if (player instanceof ComputerPlayer) {
                ComputerPlayer cplayer = (ComputerPlayer) player;
                board.calcTargets(player.getRow(), player.getCol(), 5);
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                assertEquals(3, cplayer.getCol());
                assertEquals(15, cplayer.getRow());
                
                // Assert Donald Duck does not enter the same room twice
                board.calcTargets(player.getRow(), player.getCol(), 1);
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                board.calcTargets(player.getRow(), player.getCol(), 1);
                cplayer.movePlayer(cplayer.pickLocation(board.getTargets()));
                assertFalse((15 == cplayer.getRow()) && (3 == cplayer.getCol()));
            }
        }
    }

    // Test making an accusation
    @Test
    public void testAccusation() {
        Solution correct = board.getSolution();

        // Test making a correct accusation.
        assertTrue(board.checkAccusation(correct));

        // NOTE: We are using the second item in the people, rooms and weapons
        // lists because we selected from the top of each of these lists to
        // select the solution.

        // Test making an accusation with wrong person.
        Card wrongPerson = board.getPeople().get(1);
        Solution wrongPersonSolution = new Solution(wrongPerson, correct.room, correct.weapon);
        assertFalse(board.checkAccusation(wrongPersonSolution));

        // Test making an accusation with wrong room.
        Card wrongRoom = board.getRooms().get(1);
        Solution wrongRoomSolution = new Solution(correct.person, wrongRoom, correct.weapon);
        assertFalse(board.checkAccusation(wrongRoomSolution));

        // Test making an accusation with the wrong weapon.
        Card wrongWeapon = board.getWeapons().get(1);
        Solution wrongWeaponSolution = new Solution(correct.person, correct.room, wrongWeapon);
        assertFalse(board.checkAccusation(wrongWeaponSolution));
    }

    // Test creating suggestions
    @Test
    public void testSuggestionCreation() {
        int numComputerPlayersToTest = 3;
        int i = 0;

        for (Player p : board.getPlayers()) {
            if (i >= numComputerPlayersToTest)
                break;

            // Only use ComputerPlayers
            if (p instanceof ComputerPlayer) {
                ComputerPlayer player = (ComputerPlayer) p;
                ArrayList<Card> weapons = board.getWeapons();
                ArrayList<Card> people = board.getPeople();

                Random rand = new Random();
                int personIndex = rand.nextInt(people.size());

                // Move the player to a room
                player.movePlayer(board.getCellAt(1, 0));

                // ===== Ensure that the room matches current location =====
                Solution suggestion = player.createSuggestion();
                assertEquals(board.getCellAt(1, 0).room, suggestion.room);

                // ===== Ensure that the weapon is selected randomly =====
                // If multiple weapons not seen, one of them should be randomly
                // selected. Each weapon should be chosen ~1/6 of the time.

                // "Show" the player all of the people except one.
                for (int j = 0; j < people.size(); j++) {
                    if (personIndex != j)
                        player.seeCard(people.get(j));
                }

                // Make 600 suggestions and store the number of times each
                // solution is suggested.
                Map<Solution, Integer> numOccurances = new HashMap<>();
                for (int j = 0; j < 600; j++) {
                    Solution s = player.createSuggestion();
                    int currentAmount = numOccurances.get(s) == null ? 0 : numOccurances.get(s);

                    currentAmount++;
                    numOccurances.put(s, currentAmount);
                }

                // There should only be 6 resulting Solutions
                assertTrue(numOccurances.size() == 6);

                // There should be roughly the same amount of each solution.
                for (Solution s : numOccurances.keySet()) {
                    int numOfCurrentSolution = numOccurances.get(s);
                    assertTrue(50 < numOfCurrentSolution && numOfCurrentSolution < 150);
                }

                player._resetSeenCards();

                // ===== Ensure that the person is selected randomly =====
                // If multiple persons not seen, one of them should be randomly
                // selected. Each person should be chosen ~1/6 of the time
                int weaponIndex = rand.nextInt(weapons.size());

                // "Show" the player all of the weapons except one.
                for (int j = 0; j < weapons.size(); j++) {
                    if (weaponIndex != j)
                        player.seeCard(weapons.get(j));
                }

                // Make 600 suggestions and store the number of times each
                // solution is suggested.
                numOccurances.clear();
                for (int j = 0; j < 600; j++) {
                    Solution s = player.createSuggestion();
                    int currentAmount = numOccurances.get(s) == null ? 0 : numOccurances.get(s);

                    currentAmount++;
                    numOccurances.put(s, currentAmount);
                }

                // There should only be 6 resulting Solutions
                assertTrue(numOccurances.size() == 6);

                // There should be roughly the same amount of each solution.
                for (Solution s : numOccurances.keySet()) {
                    int numOfCurrentSolution = numOccurances.get(s);
                    assertTrue(70 < numOfCurrentSolution && numOfCurrentSolution < 130);
                }

                player._resetSeenCards();

                // "Show" the player all of the weapons and people except one of
                // each.
                personIndex = rand.nextInt(people.size());
                weaponIndex = rand.nextInt(weapons.size());

                for (int j = 0; j < weapons.size(); j++) {
                    if (weaponIndex != j)
                        player.seeCard(weapons.get(j));
                }

                for (int j = 0; j < people.size(); j++) {
                    if (personIndex != j)
                        player.seeCard(people.get(j));
                }

                // Regenerate the suggestion
                suggestion = player.createSuggestion();

                // There is only one weapon that has not seen, it should be
                // selected.
                assertEquals(board.getWeapons().get(weaponIndex), suggestion.weapon);

                // There is only one person that has not seen, it should be
                // selected.
                assertEquals(board.getPeople().get(personIndex), suggestion.person);

                i++;
            }
        }
    }

    // Test disproving suggestions
    @Test
    public void testDisproveSuggestion() {
        // Setup suggestion and fake person
        Card person = new Card(CardType.PERSON, "Charlie Sheen", 'c');
        Card room = new Card(CardType.ROOM, "Library", 'L');
        Card weapon = new Card(CardType.WEAPON, "katana", 'k');
        Solution suggestion = new Solution(person, room, weapon);

        ArrayList<Card> playerCards = new ArrayList<Card>();
        ComputerPlayer player = new ComputerPlayer();

        Card c1 = new Card(CardType.PERSON, "Charlie Sheen", 'c');
        Card c2 = new Card(CardType.WEAPON, "SomethingElse", 's');
        Card c3 = new Card(CardType.PERSON, "Something Else", 'd');
        Card c4 = new Card(CardType.WEAPON, "Something2Else", 'e');
        playerCards.add(c1);
        playerCards.add(c2);
        playerCards.add(c3);
        playerCards.add(c4);
        player._setPlayerCards(playerCards);

        // Test that if disprove suggestion only receives one valid card
        Card disproveCard = null;
        disproveCard = player.disproveSuggestion(suggestion);
        assertTrue(disproveCard.getCardName().equals("Charlie Sheen"));

        // Test that if disprove suggestion chooses one valid card from many
        Card c5 = new Card(CardType.WEAPON, "katana", 'g');
        playerCards.add(c5);
        player._setPlayerCards(playerCards);

        disproveCard = player.disproveSuggestion(suggestion);
        assertTrue(disproveCard.getCardName().equals("Charlie Sheen") || disproveCard.getCardName().equals("katana"));

        // Test another card for exclusivity
        playerCards.remove(c1);
        player._setPlayerCards(playerCards);

        disproveCard = player.disproveSuggestion(suggestion);
        assertTrue(disproveCard.getCardName().equals("katana"));

        // Test 0 matching cards returns null
        playerCards.remove(c5);
        player._setPlayerCards(playerCards);

        disproveCard = player.disproveSuggestion(suggestion);
        assertTrue(disproveCard == null);
    }

    // Test handling a suggestion
    @Test
    public void testSuggestionHandling() {
        List<Player> allPlayers = board.getPlayers();
        List<Player> computerPlayers = board.getComputerPlayers();
        Player player1 = computerPlayers.get(0);
        Player player2 = computerPlayers.get(1);
        Player player3 = computerPlayers.get(2);
        Player humanPlayer = board.getHumanPlayer();
        Solution solution;

        // Test a suggestion that no one can disprove. It should return null.
        solution = board.getSolution();
        assertEquals(null, board.handleSuggestion(player1, solution));

        // Test a suggestion that only the accusing player can disprove. It
        // should return null.

        // Add some random cards to the player's hand and use that as the
        // solution.
        Card person = new Card(Card.CardType.PERSON, "Nobody", 'n');
        Card room = new Card(Card.CardType.ROOM, "Nowhere", 'o');
        Card weapon = new Card(Card.CardType.WEAPON, "Nothing", 'm');

        ArrayList<Card> cards = player1.getPlayerCards();
        cards.add(person);
        cards.add(room);
        cards.add(weapon);

        solution = new Solution(person, room, weapon);
        assertEquals(null, board.handleSuggestion(player1, solution));

        cards.remove(person);
        cards.remove(room);
        cards.remove(weapon);

        // Test a suggestion that only the human player can disprove. This
        // should return an answer.
        humanPlayer.getPlayerCards().add(person);

        assertEquals(person, board.handleSuggestion(player1, solution));

        humanPlayer.getPlayerCards().remove(person);

        // Test a suggestion that only a human can disprove, but where the human
        // is the accuser. This should return null.
        humanPlayer.getPlayerCards().add(person);

        assertEquals(null, board.handleSuggestion(humanPlayer, solution));

        humanPlayer.getPlayerCards().remove(person);

        // Test a suggestion that two players can disprove. Ensure that the
        // correct player (based on the starting positions in the list) returns
        // an answer.
        player2.getPlayerCards().add(person);
        player3.getPlayerCards().add(room);

        assertEquals(person, board.handleSuggestion(player1, solution));

        player2.getPlayerCards().remove(person);
        player3.getPlayerCards().remove(room);

        // Test a suggestion that human and another player can disprove where
        // the other player is next in the list. Ensure that the other player
        // returns the answer.
        int playerIndex = allPlayers.indexOf(humanPlayer);

        playerIndex--;
        if (playerIndex < 0)
            playerIndex = allPlayers.size() - 1;

        Player playerBeforeHuman = allPlayers.get(playerIndex);

        playerIndex--;
        if (playerIndex < 0)
            playerIndex = allPlayers.size() - 1;

        Player playerTwoBeforeHuman = allPlayers.get(playerIndex);

        playerBeforeHuman.getPlayerCards().add(person);
        humanPlayer.getPlayerCards().add(weapon);

        assertEquals(person, board.handleSuggestion(playerTwoBeforeHuman, solution));

        playerBeforeHuman.getPlayerCards().remove(person);
        humanPlayer.getPlayerCards().remove(weapon);
    }
}
