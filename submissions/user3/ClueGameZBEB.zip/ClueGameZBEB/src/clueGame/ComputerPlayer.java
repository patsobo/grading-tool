package clueGame;

import java.util.*;

public class ComputerPlayer extends Player {

	private Set<Card> seenCards;
	private Set<Card> visitedRooms;

	public ComputerPlayer(String[] playerConfig) {
		super(playerConfig);
		this.seenCards = new HashSet<Card>();
		this.visitedRooms = new HashSet<Card>();
	}

	// Testing only
	public ComputerPlayer() {
	}

	@Override
	public Card disproveSuggestion(Solution suggestion) {
		ArrayList<Card> validCards = new ArrayList<Card>();

		for (Card c : this.playerCards) {
			if (suggestion.contains(c))
				validCards.add(c);
		}

		if (validCards.size() == 0) {
			return null;
		} else {
			int rand = new Random().nextInt(validCards.size());
			return validCards.get(rand);
		}
	}

	public BoardCell pickLocation(Set<BoardCell> targets) {
		// Pick randomly from the targets no room are in the list.
		BoardCell randomCell = null;
		int moveIndex = new Random().nextInt(targets.size());
		int i = 0;

		// If one of the targets is a room, go into it.
		for (BoardCell b : targets) {
			// Do this first so that it will always be set.
			if (i <= moveIndex)
				randomCell = b;

			if (b.isDoorway() && this.visitedRooms.contains(b.room))
				continue;

			if (b.isDoorway()) {
				this.visitedRooms.add(b.room);
				return b;
			}
			i++;
		}

		return randomCell;
	}

	@Override
	public void movePlayer(BoardCell boardCell) {
			super.movePlayer(boardCell);
			this.visitedRooms.add(boardCell.room);
	}

	public void seeCard(Card c) {
		this.seenCards.add(c);
	}

	public Solution createSuggestion() {
		ArrayList<Card> people = Board.getInstance().getPeople();
		ArrayList<Card> weapons = Board.getInstance().getWeapons();

		people.removeAll(seenCards);
		weapons.removeAll(seenCards);

		Card person, weapon;

		// If we've seen every person but one, suggest that one. Otherwise,
		// suggest a random person.
		if (people.size() == 1)
			person = people.get(0);
		else
			person = people.get(new Random().nextInt(people.size()));

		// If we've seen every weapon but one, suggest that one. Otherwise,
		// suggest a random weapon.
		if (weapons.size() == 1)
			weapon = weapons.get(0);
		else
			weapon = weapons.get(new Random().nextInt(weapons.size()));

		return new Solution(person, this.currentRoom, weapon);
	}

	// Testing Only
	public void _resetSeenCards() {
		this.seenCards.clear();
	}

	public Set<Card> getSeenCards() {
		return seenCards;
	}

}
