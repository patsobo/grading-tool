package clueGame;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Card {
	public enum CardType {
		PERSON, WEAPON, ROOM, NONE
	}

	private CardType cardType;
	private String cardName;
	private Character initial;

	public Card(CardType cardType, String cardName) {
		this(cardType, cardName, null);
		if (cardType == CardType.ROOM)
			throw new InvalidParameterException("Creation of ROOM card type must be called with initial parameter.");
	}

	public Card() {

	}

	public Card(CardType cardType, String cardName, Character initial) {
		super();
		this.cardType = cardType;
		this.cardName = cardName;
		this.initial = initial;
	}

	public Card defaultCard() {
		Card c = new Card();
		c.cardType = CardType.NONE;
		c.cardName = "No Suggestions";
		c.initial = 'W';
		return c;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Card))
			return false;

		if (o == this)
			return true;

		Card c = (Card) o;
		return c.cardType == this.cardType && c.cardName == this.cardName;
	}

	public CardType getCardType() {
		return cardType;
	}

	public CardType getCard(String value) {
		
		if (this.cardName == value){
			return cardType;
		}
		

		return null;
	}

	public String getCardName() {
		return cardName;
	}

	@Override
	public String toString() {
		return "Card [cardType=" + cardType + ", cardName=" + cardName + "]";
	}

	public Character getInitial() {
		return this.initial;
	}

}
