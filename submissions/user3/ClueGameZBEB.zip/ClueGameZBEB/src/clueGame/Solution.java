package clueGame;

import clueGame.Card.CardType;

public class Solution {
    public Card person;
    public Card room;
    public Card weapon;

    public Solution(Card person, Card room, Card weapon) {
        super();
        this.person = person;
        this.room = room;
        this.weapon = weapon;
    }
    
    public Solution() {
    	super();
    }

    public boolean contains(Card c) {
        return c.equals(this.person) || c.equals(this.room) || c.equals(this.weapon);
    }
    
    public Solution defaultSuggestion(Card person) {
    	Solution newSolution = new Solution(person.defaultCard(),room.defaultCard(),weapon.defaultCard());
    	return newSolution;
    }
    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + this.person.hashCode();
        result = PRIME * result + this.room.hashCode();
        result = PRIME * result + this.weapon.hashCode();
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Solution))
            return false;

        if (o == this)
            return true;

        Solution s = (Solution) o;

        return s.person == this.person && s.room == this.room && s.weapon == this.weapon;
    }

    public boolean containsString(String s) {
        if (s.equals(person.getCardName()) || s.equals(room.getCardName()) || s.equals(weapon.getCardName())) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Solution [person=" + this.person + ", room=" + this.room + ", weapon=" + this.weapon + "]";
    }
}
