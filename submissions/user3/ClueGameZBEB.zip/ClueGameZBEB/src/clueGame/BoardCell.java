package clueGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

import com.sun.javafx.geom.Rectangle;

import clueGui.BoardGui;

/**
 * Created by Mobius on 10/4/16.
 */
public class BoardCell extends JPanel {
	/*
	 * BoardCell should be immutable, and so it makes sense for x and y to be
	 * final. Because they are final and useful, there is no reason not to make
	 * them public.
	 */
	public final int x;
	public final int y;
	public final Card room;

	public final char initial;
	public final DoorDirection door;

	public static final int BOARD_SPACE_DIMENSION = 30;
	private BoardGui drawBoard;
	private Color highLightedTarget;

	BoardCell(int x, int y, char roomType, DoorDirection door) {
		this.x = x;
		this.y = y;
		this.initial = roomType;
		this.room = this.getRoomFromChar(roomType);
		this.door = door;
		highLightedTarget = Color.MAGENTA;
	}

	@Override
	public int hashCode() {
		return (y * 31) + x;
	}

	public int getX() {
		return this.x;

	}

	public int getY() {
		return this.y;
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof BoardCell) {
			BoardCell other = (BoardCell) o;
			return other.x == x && other.y == y;
		}
		return false;
	}

	public boolean isDoorway() {
		return door != null;
	}

	public DoorDirection getDoorDirection() {
		return door;
	}

	public char getInitial() {
		return this.initial;
	}

	private Card getRoomFromChar(char c) {
		for (Card room : Board.getInstance().getRooms()) {
			if (room.getInitial() == c)
				return room;
		}

		return null;
	}

	@Override
	public String toString() {
		String roomName = this.room == null ? "" : room.getCardName();
		return "BoardCell [x=" + x + ", y=" + y + ", room=" + roomName + ", initial=" + initial + ", door=" + door
				+ "]";
	}

	public void draw(Graphics g) {
		super.paintComponents(g);

		if (this.getInitial() == 'W') {
			g.setColor(Color.BLACK);
			g.drawRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION,
					BOARD_SPACE_DIMENSION);

			g.setColor(Color.MAGENTA);
			g.fillRect(this.x * BOARD_SPACE_DIMENSION + 1, this.y * BOARD_SPACE_DIMENSION + 1,
					BOARD_SPACE_DIMENSION - 1, BOARD_SPACE_DIMENSION - 1);
			if (highLightedTarget == Color.CYAN) {
				g.setColor(Color.BLACK);
				g.drawRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION,
						BOARD_SPACE_DIMENSION);

				g.setColor(Color.CYAN);
				g.fillRect(this.x * BOARD_SPACE_DIMENSION + 1, this.y * BOARD_SPACE_DIMENSION + 1,
						BOARD_SPACE_DIMENSION - 1, BOARD_SPACE_DIMENSION - 1);
			}
		} else {

			g.setColor(Color.gray);
			g.fillRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION,
					BOARD_SPACE_DIMENSION);

			if (door != null) {
				g.setColor(Color.BLUE);
				if (getDoorDirection() == DoorDirection.UP) {

					g.fillRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION,
							5);

					if (highLightedTarget == Color.CYAN) {
						g.setColor(Color.BLACK);
						g.drawRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION,
								BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION);

						g.setColor(Color.CYAN);
						g.fillRect(this.x * BOARD_SPACE_DIMENSION + 1, this.y * BOARD_SPACE_DIMENSION + 1,
								BOARD_SPACE_DIMENSION - 1, BOARD_SPACE_DIMENSION - 1);
					}

				}
				if (getDoorDirection() == DoorDirection.DOWN) {

					g.fillRect(this.x * BOARD_SPACE_DIMENSION,
							this.y * BOARD_SPACE_DIMENSION + BOARD_SPACE_DIMENSION - 5, BOARD_SPACE_DIMENSION, 5);

					if (highLightedTarget == Color.CYAN) {
						g.setColor(Color.BLACK);
						g.drawRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION,
								BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION);

						g.setColor(Color.CYAN);
						g.fillRect(this.x * BOARD_SPACE_DIMENSION + 1, this.y * BOARD_SPACE_DIMENSION + 1,
								BOARD_SPACE_DIMENSION - 1, BOARD_SPACE_DIMENSION - 1);
					}
				}
				if (getDoorDirection() == DoorDirection.LEFT) {

					g.fillRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION, 5,
							BOARD_SPACE_DIMENSION);

					if (highLightedTarget == Color.CYAN) {
						g.setColor(Color.BLACK);
						g.drawRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION,
								BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION);

						g.setColor(Color.CYAN);
						g.fillRect(this.x * BOARD_SPACE_DIMENSION + 1, this.y * BOARD_SPACE_DIMENSION + 1,
								BOARD_SPACE_DIMENSION - 1, BOARD_SPACE_DIMENSION - 1);
					}
				}
				if (getDoorDirection() == DoorDirection.RIGHT) {

					g.fillRect(this.x * BOARD_SPACE_DIMENSION + BOARD_SPACE_DIMENSION - 5,
							this.y * BOARD_SPACE_DIMENSION, 5, BOARD_SPACE_DIMENSION);
				}
				if (highLightedTarget == Color.CYAN) {
					g.setColor(Color.BLACK);
					g.drawRect(this.x * BOARD_SPACE_DIMENSION, this.y * BOARD_SPACE_DIMENSION, BOARD_SPACE_DIMENSION,
							BOARD_SPACE_DIMENSION);

					g.setColor(Color.CYAN);
					g.fillRect(this.x * BOARD_SPACE_DIMENSION + 1, this.y * BOARD_SPACE_DIMENSION + 1,
							BOARD_SPACE_DIMENSION - 1, BOARD_SPACE_DIMENSION - 1);
				}
			}
			if (this.getInitial() == 'X' && this.x == 12 && this.y == 11) {
				g.setColor(Color.BLUE);
				String name = "CLOSET";
				g.drawString(name, this.x * BOARD_SPACE_DIMENSION - 32, this.y * BOARD_SPACE_DIMENSION);
			}

			if (getDoorDirection() == DoorDirection.NONE) {

				String name = room.getCardName();
				g.drawString(name, this.x * BOARD_SPACE_DIMENSION - 17, this.y * BOARD_SPACE_DIMENSION);
			}

		}

	}


	public void setCanMove(Color canMove) {
		this.highLightedTarget = canMove;
	}

}
