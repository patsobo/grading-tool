package clueGame;

import java.awt.Color;
import java.awt.Graphics;
import java.lang.reflect.Field;
import java.util.*;
import clueGui.MainControl;

import clueGame.Card.CardType;


public abstract class Player {
    protected String playerName;
    protected Color color;
    protected int row;
    protected int col;
    protected Card currentRoom;
    protected BoardCell currentBoardCell;
    protected ArrayList<Card> playerCards;
    Board board = Board.getInstance();
    protected boolean makeAccusation;
    protected Solution currentSolution;


    public Player(String[] playerConfig) {
        super();
        this.playerName = playerConfig[0];
        this.color = this.convertColor(playerConfig[1]);
        this.row = Integer.parseInt(playerConfig[2]);
        this.col = Integer.parseInt(playerConfig[3]);
        this.makeAccusation = false;

        this.playerCards = new ArrayList<Card>();
    }

    // for testing
    public Player() {
        this.playerCards = new ArrayList<Card>();
    }

    @Override
    public String toString() {
        return "Player [playerName=" + playerName + ", color=" + color + ", row=" + row + ", col=" + col + "]";
    }

    public void movePlayer(BoardCell boardCell) {
        this.currentRoom = boardCell.room;
        this.currentBoardCell = boardCell;
        this.row = boardCell.y;
        this.col = boardCell.x;

    }
    
    
    abstract Card disproveSuggestion(Solution suggestion);

    public String getPlayerName() {
        return playerName;
    }

    public Card getCurrentRoom() {
        return this.currentRoom;
    }

    public BoardCell getBoardCell() {
    	return currentBoardCell;
    }
    
    public void setCurrentBoardCell(BoardCell b) {
    	this.currentBoardCell = b;
    }
    public Color getColor() {
        return color;
    }
    

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }
    
    public void setRow(int row){
    	this.row = row;
    }
    
    public void setCol(int col) {
    	this.col = col;
    }

    public ArrayList<Card> getPlayerCards() {
        return this.playerCards;
    }
    
    public void setMakeAccusation() {
    	if (!this.makeAccusation)
    		this.makeAccusation = true;
    	else 
    		this.makeAccusation = false;
    }

    public void giveCardToPlayer(Card card) {
        this.playerCards.add(card);
    }
    
    public void setCurrentSolution(Solution s) {
    	this.currentSolution = s;
    }
    
    public Solution getCurrentSolution() {
    	return this.currentSolution;
    }

    private Color convertColor(String strColor) {
        Color color;
        try {
            // Use reflection to convert the string to a color
            Field field = Class.forName("java.awt.Color").getField(strColor.trim().toUpperCase());
            color = (Color) field.get(null);
        } catch (Exception e) {
            color = null; // Not defined
        }
        return color;
    }

    // Testing only
    public void _setPlayerCards(ArrayList<Card> playerCards) {
        this.playerCards = playerCards;
    }
    
    public void draw(Graphics g){
    	g.setColor(color);
    	g.fillRoundRect(col*30, row*30, 28, 28, 100, 100);
    	g.drawRoundRect(col*30, row*30, 28, 28, 100, 100);
    }

	abstract public BoardCell pickLocation(Set<BoardCell> targets);



    
}
