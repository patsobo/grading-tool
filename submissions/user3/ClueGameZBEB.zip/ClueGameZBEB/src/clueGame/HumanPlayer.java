package clueGame;

import java.awt.Color;
import java.util.Set;
import clueGui.*;

public class HumanPlayer extends Player {
	
    public HumanPlayer(String[] playerConfig) {
        super(playerConfig);
        // TODO Auto-generated constructor stub
        
    }

    @Override
    Card disproveSuggestion(Solution suggestion) {
        // TODO Auto-generated method stub
        return null;
    }
    
    @Override
    public String getPlayerName() {
    	return this.playerName;
    }
    
    @Override
    public void movePlayer(BoardCell boardCell) {
    	super.movePlayer(boardCell);
    }

	@Override
	public BoardCell pickLocation(Set<BoardCell> targets) {
		// TODO Auto-generated method stub
		return null;
	}

}
