package clueGame;


public enum DoorDirection {
	DOWN(0, 1),
	LEFT(-1, 0),
	UP(0, -1),
	RIGHT(1, 0),
	NONE(0,0);

	public final int DX;
	public final int DY;

	DoorDirection(int dx, int dy) {
		this.DX = dx;
		this.DY = dy;
	}

	public boolean isFromTo(BoardCell from, BoardCell to) {
		int dx = to.x - from.x;
		int dy = to.y - from.y;

		return this.DX == dx && this.DY == dy;
	}
}
