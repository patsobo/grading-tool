package clueGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
import java.util.function.BiPredicate;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import clueGame.Card.CardType;
import clueGui.GameControl;
import clueGui.MainControl;
import clueGui.MouseClick;
import clueGui.updateGuess;

/**
 * Created by Mobius on 10/4/16.
 */

public class Board extends JPanel {
	// variable used for singleton pattern
	public static Board theInstance = new Board();

	public static Board getInstance() {
		return theInstance;
	}

	private MouseClick click;

	public boolean roomTruth;

	private int width;
	private int height;
	private BoardCell[] grid;
	private Set<BoardCell>[] adj;

	private ArrayList<Player> players;
	private ArrayList<Card> cards;
	private Solution solution;
	private String[] playerGuess;
	private String resultCard;

	private Map<Character, String> legend = new HashMap<>();

	private boolean layoutLoaded = false;
	private boolean legendLoaded = false;
	private boolean humanHasFinishedTurn = false;
	private boolean displaySuggestionPanel = false;
	public boolean allowedToMakeAccusation = false;

	private String layoutSource;
	private String legendSource;
	private String peopleSource;
	private String weaponSource;
	boolean isFirstTime = true;

	private GameControl gc;

	private Board() {
	}

	private void checkLoaded() {
		if (!layoutLoaded || !legendLoaded) {
			throw new IllegalStateException("Board data not loaded");
		}
	}

	public BoardCell getCellAt(int row, int column) {
		return getCellAtXY(column, row);
	}

	public BoardCell getCellAtXY(int x, int y) {
		checkLoaded();
		if (x < 0 || y < 0 || x >= width || y >= height)
			return null;
		return grid[x + y * width];
	}

	public Set<BoardCell> getAdjList(int row, int column) {
		return getAdjListXY(column, row);
	}

	public Set<BoardCell> getAdjListXY(int x, int y) {
		checkLoaded();
		if (x < 0 || y < 0 || x >= width || y >= height)
			throw new IllegalArgumentException();
		return adj[x + y * width];
	}

	private void calcTargetsImpl(int x, int y, int pathLength, Set<BoardCell> visited, Collection<BoardCell> targets) {
		for (BoardCell c : getAdjListXY(x, y)) {
			if (!visited.contains(c)) {
				visited.add(c);
				if (c.isDoorway())
					targets.add(c);
				else if (pathLength == 1)
					targets.add(c);
				else
					calcTargetsImpl(c.x, c.y, pathLength - 1, visited, targets);
				visited.remove(c);
			}
		}
	}

	public void calcTargets(int row, int column, int steps) {
		calcTargetsXY(column, row, steps);
	}

	private Set<BoardCell> targets;

	@Deprecated
	public Set<BoardCell> calcTargetsXY(int x, int y, int steps) {
		checkLoaded();
		if (x < 0 || y < 0 || x >= width || y >= height || steps < 0)
			throw new IllegalArgumentException();

		Set<BoardCell> targets = new HashSet<>();
		HashSet<BoardCell> visited = new HashSet<>();
		visited.add(getCellAtXY(x, y));
		calcTargetsImpl(x, y, steps, visited, targets);
		this.targets = targets;
		return targets;
	}

	public Set<BoardCell> getTargets() {
		return targets;
	}

	public void clearAdjacencies() {
		checkLoaded();
		for (int i = 0; i < grid.length; i++) {
			adj[i].clear();
		}
	}

	public void calcAdjacencies(BiPredicate<BoardCell, BoardCell> adjacencyRules) {
		clearAdjacencies();
		for (int i = 0; i < grid.length; i++) {
			int x = i % width;
			int y = i / width;
			BoardCell at = grid[i];

			if (x > 0) {
				BoardCell to = grid[i - 1];
				if (adjacencyRules.test(at, to))
					adj[i].add(to);
			}

			if (x < width - 1) {
				BoardCell to = grid[i + 1];
				if (adjacencyRules.test(at, to))
					adj[i].add(to);
			}

			if (y > 0) {
				BoardCell to = grid[i - width];
				if (adjacencyRules.test(at, to))
					adj[i].add(to);
			}

			if (y < height - 1) {
				BoardCell to = grid[i + width];
				if (adjacencyRules.test(at, to))
					adj[i].add(to);
			}
		}
	}

	private static InputStream getFileStream(String path) throws FileNotFoundException {
		ClassLoader cl = Board.class.getClassLoader();
		InputStream stream = cl.getResourceAsStream(path);

		if (stream == null) {
			try {
				stream = new FileInputStream(new File(new File("data/"), path));
			} catch (FileNotFoundException ignored) {
			}
		}

		if (stream == null)
			throw new FileNotFoundException(String.format("Could not find file %s in jar or data/", path));

		return stream;
	}

	public void setConfigFiles(String layout, String legend, String people, String weapons) {
		this.layoutSource = layout;
		this.legendSource = legend;
		this.peopleSource = people;
		this.weaponSource = weapons;
	}

	public void initialize() {
		try {
			this.cards = new ArrayList<Card>();

			loadRoomConfig();
			loadBoardConfig();
			loadPeopleConfig();
			loadWeaponConfig();

			calcAdjacencies((a, b) -> {
				if (a.isDoorway())
					if (a.getDoorDirection().isFromTo(a, b))
						return true;
				if (b.isDoorway())
					if (b.getDoorDirection().isFromTo(b, a))
						return true;
				return a.initial == 'W' && b.initial == 'W';
			});

			shuffleCards();
			selectAnswer();
			dealCards();
			playerGuess = new String[3];
			playerGuess[0] = "";
			playerGuess[1] = "";
			playerGuess[2] = "";

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void loadRoomConfig() throws BadConfigFormatException, FileNotFoundException {
		legendLoaded = false;
		legend.clear();

		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(getFileStream(legendSource)));

		int lineIn = 1;

		while (true) {
			// get line
			String line;
			try {
				line = bufferedReader.readLine();
			} catch (IOException e) {
				throw new BadConfigFormatException("Some IOException occurred", e);
			}

			// EOF
			if (line == null)
				break;

			String[] words = line.split(",");
			if (words.length != 3)
				throw new BadConfigFormatException("Bad legend format on line " + lineIn);

			char c = words[0].trim().charAt(0);
			String name = words[1].trim();
			String type = words[2].trim();

			switch (type) {
			case "Card":
				this.cards.add(new Card(Card.CardType.ROOM, name, c));
				break;
			case "Other":
				// Do nothing
				break;
			default:
				throw new BadConfigFormatException("\"" + type + "\" is not a valid room type");
			}

			legend.put(c, name);

			lineIn++;
		}

		legendLoaded = true;
	}

	private BoardCell makeCell(int x, int y, String data) throws BadConfigFormatException {
		DoorDirection door = null;
		if (data.length() > 1) {
			switch (Character.toUpperCase(data.charAt(1))) {
			case 'U':
				door = DoorDirection.UP;
				break;
			case 'D':
				door = DoorDirection.DOWN;
				break;
			case 'L':
				door = DoorDirection.LEFT;
				break;
			case 'R':

				door = DoorDirection.RIGHT;
				break;
			case 'N':

				door = DoorDirection.NONE;
				break;
			}
		}

		char type = data.charAt(0);
		if (!legend.containsKey(type)) {
			throw new BadConfigFormatException("\"" + type + "\" is not in the legend");
		}

		return new BoardCell(x, y, type, door);
	}

	public void loadBoardConfig() throws BadConfigFormatException, FileNotFoundException {
		layoutLoaded = false;

		if (!legendLoaded) {
			throw new BadConfigFormatException("No legend is loaded");
		}

		BufferedReader r = new BufferedReader(new InputStreamReader(getFileStream(layoutSource)));

		ArrayList<BoardCell> list = new ArrayList<>();
		boolean first = true;
		int y = -1;
		while (true) {
			// get line
			String line;
			try {
				line = r.readLine();
			} catch (IOException e) {
				throw new BadConfigFormatException("Some IOException occurred", e);
			}

			// EOF
			if (line == null)
				break;

			// next line
			y++;
			String[] cells = line.split(",");

			if (first) {
				width = cells.length;
				first = false;
			}
			if (width != cells.length)
				throw new BadConfigFormatException("Inconsistent width on line " + (y + 1));

			int x = 0;
			for (String cell : cells) {
				list.add(makeCell(x++, y, cell.trim()));
			}
		}
		height = y + 1;

		// fill arrays
		grid = new BoardCell[width * height];
		list.toArray(grid);

		// the weird cast is to deal with java's refusal to have generic types
		// in an array definitions
		adj = (Set<BoardCell>[]) Array.newInstance(Set.class, width * height);
		for (int i = 0; i < grid.length; i++) {
			adj[i] = new HashSet<>();
		}

		layoutLoaded = true;
	}

	public int rollDice() {
		// Random is 0 based but the dice is 1 based
		return new Random().nextInt(5) + 1;
	}

	private void loadPeopleConfig() throws BadConfigFormatException {
		try (FileReader reader = new FileReader("data/" + this.peopleSource)) {
			Scanner peopleFileScanner = new Scanner(reader);

			int humanPlayerIndex = new Random().nextInt(5);

			int i = 0;

			this.players = new ArrayList<Player>();

			// Add each person
			while (peopleFileScanner.hasNextLine()) {
				String line = peopleFileScanner.nextLine();
				String[] tokens = line.split(",");

				// If this is the human player's index, add a HumanPlayer.
				// Otherwise, add a ComputerPlayer.
				this.players.add(i == humanPlayerIndex ? new HumanPlayer(tokens) : new ComputerPlayer(tokens));
				this.cards.add(new Card(Card.CardType.PERSON, tokens[0]));

				i++;
			}

			peopleFileScanner.close();
		} catch (IOException ex) {
			throw new BadConfigFormatException(ex);
		}
	}

	private void loadWeaponConfig() throws BadConfigFormatException {
		try (FileReader reader = new FileReader("data/" + this.weaponSource)) {
			Scanner peopleFileScanner = new Scanner(reader);

			// Add each person
			while (peopleFileScanner.hasNextLine()) {
				String line = peopleFileScanner.nextLine();
				this.cards.add(new Card(Card.CardType.WEAPON, line));
			}

			peopleFileScanner.close();
		} catch (IOException ex) {
			throw new BadConfigFormatException(ex);
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		for (BoardCell boardCell : grid) {
			boardCell.draw(g);

		}
		for (Player p : getPlayers()) {
			p.draw(g);
		}
	}

	private void shuffleCards() {
		// Shuffle the cards
		Collections.shuffle(this.cards);
	}

	private void selectAnswer() {
		// Select the top card of each type of card as the solution. (The cards
		// have already been shuffled at this point.)
		this.solution = new Solution(this.getPeople().get(0), this.getRooms().get(0), this.getWeapons().get(0));
	}

	private void dealCards() {
		int i = 0;
		for (Card c : this.cards) {
			if (!this.solution.contains(c)) {
				this.players.get(i).giveCardToPlayer(c);

				// Increment to the next player or go back to the first one if
				// we've gone through all of the players
				i = i < players.size() - 1 ? i + 1 : 0;
			}
		}
	}

	public Card handleSuggestion(Player player, Solution solution) {
		// Start testing suggestion from the next indexed player
		int playerIndex = this.players.indexOf(player) + 1;
		player.setCurrentSolution(solution);

		if (playerIndex >= this.players.size())
			playerIndex = 0;

		// Find the first player that has a card that is in the solution and
		// return that card. If nobody has a card in the solution, return null.
		while (this.players.get(playerIndex) != player) {
			for (Card c : this.players.get(playerIndex).getPlayerCards()) {
				if (solution.contains(c)) {
					resultCard = c.getCardName();
					return c;
				}
			}

			playerIndex++;

			// Wrap around to the beginning
			if (playerIndex >= this.players.size())
				playerIndex = 0;

			if ((playerIndex == this.players.indexOf(player)) && (player instanceof ComputerPlayer)) {
				player.setMakeAccusation();
			}
		}
		return null;
	}

	public ArrayList<Card> getCards() {
		return this.cards;
	}

	public Map<Character, String> getLegend() {
		if (!legendLoaded)
			return null;
		return legend;
	}

	public int getNumRows() {
		if (!layoutLoaded)
			return 0;
		return height;
	}

	public int getNumColumns() {
		if (!layoutLoaded)
			return 0;
		return width;
	}

	public Player getPlayer(String name) {
		for (Player p : this.players) {
			if (p.getPlayerName().equals(name))
				return p;
		}

		return null;
	}

	public Card getCard(String name) {
		for (Card w : this.cards) {
			if (w.getCardName().equals(name))
				return w;
		}

		return null;
	}

	public Solution getSolution() {
		return this.solution;
	}

	public ArrayList<Player> getPlayers() {
		ArrayList<Player> sortedList = new ArrayList<Player>();
		sortedList.add(getHumanPlayer());

		for (Player p : this.getComputerPlayers()) {
			sortedList.add(p);
		}
		return sortedList;
	}

	public Player getHumanPlayer() {
		for (Player p : players) {
			if (p instanceof HumanPlayer) {
				return p;
			}
		}
		return null;
	}

	public List<Player> getComputerPlayers() {
		ArrayList<Player> computerPlayers = new ArrayList<>();

		for (Player p : players) {
			if (p instanceof ComputerPlayer)
				computerPlayers.add(p);
		}

		return computerPlayers;
	}

	public ArrayList<Card> getWeapons() {
		ArrayList<Card> weapons = new ArrayList<Card>();

		for (Card c : this.cards) {
			if (c.getCardType() == Card.CardType.WEAPON) {
				weapons.add(c);
			}
		}

		return weapons;
	}

	public ArrayList<Card> getPeople() {
		ArrayList<Card> people = new ArrayList<Card>();

		for (Card c : this.cards) {
			if (c.getCardType() == Card.CardType.PERSON) {
				people.add(c);
			}
		}

		return people;
	}

	public ArrayList<Card> getRooms() {
		ArrayList<Card> rooms = new ArrayList<Card>();

		for (Card c : this.cards) {
			if (c.getCardType() == Card.CardType.ROOM) {
				rooms.add(c);
			}
		}

		return rooms;
	}

	public boolean checkAccusation(Solution s) {
		return this.solution.equals(s);
	}

	public boolean isHumanHasFinishedTurn() {
		return humanHasFinishedTurn;
	}

	public void setHumanHasFinishedTurn(boolean humanHasFinishedTurn) {
		this.humanHasFinishedTurn = humanHasFinishedTurn;
	}

	public void makeMove(int roll) {
		// The board will always know the players location
		//if (!gc.accusationMade) {
			calcTargets(getHumanPlayer().getRow(), getHumanPlayer().getCol(), roll);
			Set<BoardCell> targs = getTargets();
			click = new MouseClick();
			for (BoardCell i : targs) {
				i.setCanMove(Color.CYAN);
			}

			addMouseListener(click);
			repaint();
		//}

	}

	public void repaintTargets() {
		removeMouseListener(click);
		Set<BoardCell> targs = getTargets();
		for (BoardCell i : targs) {
			i.setCanMove(Color.MAGENTA);
		}
	}

	public boolean getDisplaySuggestionPanel() {
		return displaySuggestionPanel;
	}

	public void finishMove() {

		for (BoardCell i : getTargets()) {
			i.setCanMove(null);
		}
		repaint();
	}

	public String[] getPlayerGuess() {
		return playerGuess;
	}

	public String getResultCard() {
		return resultCard;
	}

	// This will be the comp at num computerPlayer
	public void compMove(int num, int diceRoll) {

		// Calculate targets and move computer player to a new location
		ComputerPlayer computerPlayer = (ComputerPlayer) getComputerPlayers().get(num);
		if (!computerPlayer.makeAccusation) {
			calcTargets(computerPlayer.getRow(), computerPlayer.getCol(), diceRoll);
			BoardCell move = computerPlayer.pickLocation(targets);
			computerPlayer.movePlayer(move);

			// make a suggestion if within a room.
			if (move.getInitial() != 'W') {

				// make a suggestion if within a room
				Solution guess = computerPlayer.createSuggestion();
				playerGuess[0] = guess.person.getCardName();
				playerGuess[1] = guess.room.getCardName();
				playerGuess[2] = guess.weapon.getCardName();

				// pull other player that is suggested into current room
				Player accusedPlayer = getPlayer(guess.person.getCardName());
				accusedPlayer.movePlayer(move);

				// call handle suggestion
				computerPlayer.seeCard(handleSuggestion(computerPlayer, guess));

			}
		} else {
			Solution solution = computerPlayer.getCurrentSolution();
			JFrame frame = new JFrame();
			JOptionPane gameWon = new JOptionPane();

			if (checkAccusation(solution)) {
				// pop up a dialogue that confirms computer win
				JOptionPane.showMessageDialog(frame,
						computerPlayer.getPlayerName() + " Accused " + solution.person.getCardName()
								+ " of MURDER in the " + solution.room.getCardName() + " with the "
								+ solution.weapon.getCardName() + " \n WHICH IS CORRECT!",
						"Too Bad GAME OVER", gameWon.INFORMATION_MESSAGE);
				System.exit(0);
			} else {
				// pop up a dialougue that says solution is wrong
				JOptionPane.showMessageDialog(frame,
						computerPlayer.getPlayerName() + " Accused " + solution.person.getCardName()
								+ " of MURDER in the " + solution.room.getCardName() + " with the "
								+ solution.weapon.getCardName() + " \n which is WRONG!",
						"Accusation Made", gameWon.INFORMATION_MESSAGE);
				// reset flag
				computerPlayer.setMakeAccusation();
			}
		}
		repaint();
	}

}
