package clueGui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.*;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.HumanPlayer;
import clueGame.Player;
import clueGame.Solution;

public class GameControl extends JPanel {

	static Board board;
	UpdateDie diePanel;
	updateWhoseTurn whoseTurn;
	updateGuess guess;
	GuessResult guessResult;
	private static SuggestionFrame sf = new SuggestionFrame();
	private static AccusationFrame ap;
	public boolean accusationMade = false;


	private ArrayList<String> suggestionGuess = new ArrayList<String>();
	private String whosTurn = "Press Next to Start";
	private String dieLabel = "0";
	private String playerTurn = "";
	private int roll;
	

	public GameControl() {
		this.board = Board.getInstance();
		this.setSize(new Dimension(800, 300));
		this.createLayout();
	}

	private void createLayout() {

		// board.guessUpdate();

		this.setLayout(new FlowLayout(FlowLayout.LEFT));

		// ===== Top row =====
		JPanel topPanel = new JPanel();

		// Whose Turn display
		JPanel whoseTurnDisplay = new JPanel();
		whoseTurnDisplay.setLayout(new BorderLayout());

		// Whose Turn label
		JLabel whoseTurnLabel = new JLabel("Whose turn?");
		whoseTurnDisplay.add(whoseTurnLabel, BorderLayout.NORTH);

		// Whose Turn input
		whoseTurn = new updateWhoseTurn();
		topPanel.add(whoseTurn);

		// Next Player button
		JButton nextPlayer = new JButton("Next Player");
		nextPlayer.addActionListener(new NextPlayerListener());
		topPanel.add(nextPlayer);

		// Make an Accusation button
		JButton makeAnAccusation = new JButton("Make an Accusation");
		makeAnAccusation.addActionListener(new MakeAccusationListener());
		topPanel.add(makeAnAccusation);

		this.add(topPanel);

		// ===== Bottom Row =====
		JPanel bottomPanel = new JPanel();
		diePanel = new UpdateDie();
		bottomPanel.add(diePanel);

		// Suggestion Display
		guess = new updateGuess();
		bottomPanel.add(guess);

		guessResult = new GuessResult();
		bottomPanel.add(guessResult);

		this.add(bottomPanel);
		
	}

	class NextPlayerListener implements ActionListener {
		

		private int currentPlayerIndex = 0;
		private int humanPlayerIndex = 0;
		private boolean error = false;

		public void actionPerformed(ActionEvent e) {
			whoseTurn.setWhosTurn(board.getPlayers().get(currentPlayerIndex).getPlayerName());

			if (!error)
				diePanel.setRoll();
			
			guess.setPlayerGuess();
			GuessResult.updateGuessResult();

			if (currentPlayerIndex == humanPlayerIndex) {
				board.allowedToMakeAccusation = true;

				if (board.isHumanHasFinishedTurn()) {
					error = false;
					currentPlayerIndex++;
					actionPerformed(e);
				} else {
					board.makeMove(diePanel.getRoll());
					if (error) {
						JFrame frame = new JFrame();
						JOptionPane wrong = new JOptionPane();
						JOptionPane.showMessageDialog(frame, "Finish Your Turn", "Try again",
								JOptionPane.INFORMATION_MESSAGE);
					}
					error = true;
				}

			} else {
				board.allowedToMakeAccusation = false;
				board.setHumanHasFinishedTurn(false);
				board.repaintTargets();
				board.compMove(currentPlayerIndex - 1, diePanel.getRoll());
				currentPlayerIndex++;
			}
			// ++currentPlayerIndex;

			if (currentPlayerIndex == 6) {
				currentPlayerIndex = 0;
			}

		}
	}

	class MakeAccusationListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			accusationMade = true;
			if (board.allowedToMakeAccusation == false) {
				JFrame frame = new JFrame();
				JOptionPane wrong = new JOptionPane();
				JOptionPane.showMessageDialog(frame,
						"Sorry! Not your turn! You can only make an accusation on your turn", "Okay...",
						JOptionPane.INFORMATION_MESSAGE);
			} else {
				setAccusationFrame();
				board.setHumanHasFinishedTurn(true);
				board.repaintTargets();
				board.finishMove();
			}

		}

	}

	public static void setAccusationFrame() {
		ap = new AccusationFrame();
		ap.add(new AccusationPanel());
		ap.setVisible(true);
	}

	public static void setSuggestionFrame(boolean value) {
		sf.add(new SuggestionPanel(board.getPeople(), board.getHumanPlayer().getCurrentRoom(), board.getWeapons()),
				BorderLayout.CENTER);
		sf.setVisible(value);
	}

	// I have no idea why this is necessary, just including it to make Eclipse
	// stop complaining.
	private static final long serialVersionUID = -8882717452920163836L;
}
