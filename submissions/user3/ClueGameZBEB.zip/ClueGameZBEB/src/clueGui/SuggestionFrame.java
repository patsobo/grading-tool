package clueGui;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JFrame;

import clueGame.Board;
import clueGame.Card;
import clueGame.Player;
import clueGame.Solution;

public class SuggestionFrame extends JFrame {

	public SuggestionFrame() {

		this.setTitle("Make A Suggestion");
		this.setSize(500, 300);
		// setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Solution humanSolution = new Solution();

				humanSolution.weapon = SuggestionPanel.getWeaponValue();
				humanSolution.person = SuggestionPanel.getPersonValue();
				humanSolution.room = Board.getInstance().getHumanPlayer().getCurrentRoom();

				updateGuess.setHumanGuess(humanSolution);
				GuessResult.updateGuessResult();
				Player accusedPlayer = Board.getInstance().getPlayer(humanSolution.person.getCardName());
				Board.getInstance().handleSuggestion(Board.getInstance().getHumanPlayer(), humanSolution);
				accusedPlayer.movePlayer(Board.getInstance().getHumanPlayer().getBoardCell());
				Board.getInstance().setHumanHasFinishedTurn(true);
			}
		});
	}
}
