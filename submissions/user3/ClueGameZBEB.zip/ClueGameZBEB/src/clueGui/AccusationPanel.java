package clueGui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import clueGame.Board;
import clueGame.Card;

public class AccusationPanel extends JPanel {
	private ArrayList<Card> person = Board.getInstance().getPeople();
	private ArrayList<Card> weapons = Board.getInstance().getWeapons();
	private ArrayList<Card> room = Board.getInstance().getRooms();

	private static JComboBox<String> personGuess = new JComboBox<String>();
	private static JComboBox<String> weaponGuess = new JComboBox<String>();
	private static JComboBox<String> roomGuess = new JComboBox<String>();

	public AccusationPanel() {
		this.setSize(new Dimension(400, 400));
		this.createLayout();
	}

	private void createLayout() {

		// Give the display two rows
		this.setLayout(new GridLayout(3, 1));

		// Create check Boxes and Combo Boxes for all 3 card types
		createIcons(person, "Who's hands are not clean?", 0);
		createIcons(weapons, "Whats bloody?", 1);
		createIcons(room, "Where is it bloody?", 2);
	}

	private void createIcons(ArrayList<Card> object, String borderTitle, int index) {
		// player Notes display
		JPanel comboBoxDisplay = new JPanel();

		// Make a subpanel border for people cards
		Border borderComboBox = BorderFactory.createTitledBorder("Your best Accusation");
		comboBoxDisplay.setBorder(borderComboBox);

		// Add people notes
		for (Card c : object) {
			if (index == 0) {
				personGuess.addItem(c.getCardName());
				comboBoxDisplay.add(personGuess);
			}

			if (index == 1) {
				weaponGuess.addItem(c.getCardName());
				comboBoxDisplay.add(weaponGuess);
			}
			if (index == 2) {
				roomGuess.addItem(c.getCardName());
				comboBoxDisplay.add(roomGuess);
			}
		}
		
		this.add(comboBoxDisplay);
	}

	public static Card getWeaponValue() {

		weaponGuess.addActionListener(weaponGuess);
		Card weaponCard = new Card();
		String value = (String) weaponGuess.getSelectedItem();
		for (Card c : Board.getInstance().getWeapons()) {
			if (c.getCardName() == value)
				weaponCard = c;
		}
		return weaponCard;
	}

	public static Card getPersonValue() {
		personGuess.addActionListener(personGuess);
		String value = (String) personGuess.getSelectedItem();
		Card personCard = new Card();
		for (Card c : Board.getInstance().getPeople()) {
			if (c.getCardName() == value)
				personCard = c;
		}
		return personCard;
	}
	
	public static Card getRoomValue() {
		roomGuess.addActionListener(roomGuess);
		String value = (String) roomGuess.getSelectedItem();
		Card personCard = new Card();
		for (Card c : Board.getInstance().getRooms()) {
			if (c.getCardName() == value)
				personCard = c;
		}
		return personCard;
	}

	

}
