package clueGui;

import java.awt.GridLayout;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import clueGame.Board;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import clueGame.Board;

public class GuessResult extends JPanel {
	private static JTextArea guess;
	public static Board board = Board.getInstance();

	public GuessResult() {
		setLayout(new GridLayout(1, 2));
		setBorder(new TitledBorder(new EtchedBorder(), "Guess Result"));
		guess = new JTextArea(1, 10);
		add(guess);
	}

	public static void updateGuessResult() {

		if (board.getResultCard() != null) {
			guess.setText(board.getResultCard());
		}else {
			guess.setText("No new clues");
		}
	}

}
