package clueGui;

import javax.swing.JFrame;

public class PlayerNotesFrame extends JFrame {

	private static final long serialVersionUID = 184958805150516796L;

	public PlayerNotesFrame() {

		this.setTitle("Player Notes");
		this.setSize(800, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
