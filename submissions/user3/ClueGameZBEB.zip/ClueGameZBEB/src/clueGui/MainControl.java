package clueGui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import org.junit.BeforeClass;

import clueGame.Board;
import clueGame.Card;
import clueGame.Card.CardType;
import clueGame.HumanPlayer;
import clueGame.Player;

public class MainControl extends JFrame {

	
	public static Board board;

	
	// These are to hold the card names.
	private String nameCardOne = "";
	private String nameCardTwo = "";
	private String roomCardOne = "";
	private String roomCardTwo = "";
	private String weaponCardOne = "";
	private String weaponCardTwo = "";
	private static boolean truth = false;

	private PlayerNotesFrame pn = new PlayerNotesFrame();
	private static SuggestionFrame sf = new SuggestionFrame();
	

	public void setUp() {
		// Board is singleton, get the only instance and initialize it
		board = Board.getInstance();
		board.setConfigFiles("board_layout_JEZB.csv", "legend.txt", "people.txt", "weapons.txt");
		board.initialize();
		
		// draw board
		add(board);
		// add notes feature
		pn.add(new PlayerNotes(board.getPeople(), board.getRooms(), board.getWeapons()), BorderLayout.CENTER);
		
		JPanel panel = new JPanel();
		String name = board.getHumanPlayer().getPlayerName();
		String message = "You are playing as " + name + ", Press 'Next Player' to start ";
		String title = "Welcome to Clue";
		JOptionPane.showMessageDialog(panel, message, title, JOptionPane.INFORMATION_MESSAGE);
	}

	public MainControl() {
		this.setTitle("Clue");
		this.setSize(1200, 900);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setUp();

		add(CardsOnSide(), BorderLayout.EAST);
		this.add(new GameControl(), BorderLayout.SOUTH);
		//repaint();
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		menuBar.add(createFileMenu());
	}

	private JMenu createFileMenu() {
		JMenu menu = new JMenu("File");
		menu.add(createFileExitItem());
		menu.add(createScoreCard());
		return menu;
	}

	private JMenuItem createFileExitItem() {
		JMenuItem item = new JMenuItem("Exit");
		class MenuItemListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		}
		item.addActionListener(new MenuItemListener());
		return item;
	}
	
	public JMenuItem createScoreCard() {
		JMenuItem item = new JMenuItem("Player Notes");

		class MenuItemListener implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				pn.setVisible(true);
			}
		}
		item.addActionListener(new MenuItemListener());
		return item;
	}
	

	private JPanel CardsOnSide() { // Need to get the size right
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(3, 1));
		panel.setBorder(new TitledBorder(new EtchedBorder(), "My Cards"));
		panel.setPreferredSize(new Dimension(200, 500));

		JPanel panelPeople = new JPanel();
		JPanel panelRooms = new JPanel();
		JPanel panelWeapons = new JPanel();

		JTextArea people = new JTextArea(3, 10);
		JTextArea rooms = new JTextArea(3, 10);
		JTextArea weapons = new JTextArea(3, 10);

		panelPeople.setBorder(new TitledBorder(new EtchedBorder(), "People"));
		panelRooms.setBorder(new TitledBorder(new EtchedBorder(), "Rooms"));
		panelWeapons.setBorder(new TitledBorder(new EtchedBorder(), "Weapons"));
		
		String roomString = "", weaponString = "", peopleString = "";

		for (Card c:board.getHumanPlayer().getPlayerCards() ) {
			
			if (c.getCardType() == CardType.ROOM) 
				roomString += c.getCardName() + "\n";
			if (c.getCardType() == CardType.WEAPON) 
				weaponString += c.getCardName() + "\n";
			if (c.getCardType() == CardType.PERSON) 
				peopleString += c.getCardName() + "\n";
		}
		
		people.setText(peopleString);
		rooms.setText(roomString);
		weapons.setText(weaponString);

		panelPeople.add(people);
		panelRooms.add(rooms);
		panelWeapons.add(weapons);

		panel.add(panelPeople);
		panel.add(panelRooms);
		panel.add(panelWeapons);

		return panel;

	}
	
	public static void setSuggstionFrame(boolean value) {
		SuggestionPanel sp = new SuggestionPanel(board.getPeople(),board.getHumanPlayer().getCurrentRoom(),board.getWeapons());
		sf.add(sp,BorderLayout.CENTER);
		sf.setVisible(value);
	}
	
	
	public static void main(String[] args) {
		MainControl mc = new MainControl();
		mc.setVisible(true);
		

	}

}
