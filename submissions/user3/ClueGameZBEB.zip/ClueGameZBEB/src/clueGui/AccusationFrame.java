package clueGui;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import clueGame.Board;
import clueGame.Card;
import clueGame.Player;
import clueGame.Solution;

public class AccusationFrame extends JFrame {

	public AccusationFrame() {

		this.setTitle("Make an Accusation");
		this.setSize(800, 500);
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Solution humanSolution = new Solution();
				JFrame frame = new JFrame();
				JOptionPane gameWon = new JOptionPane();

				humanSolution.weapon = AccusationPanel.getWeaponValue();
				humanSolution.person = AccusationPanel.getPersonValue();
				humanSolution.room = AccusationPanel.getRoomValue();

				if (!Board.getInstance().checkAccusation(humanSolution)) {

					// pop up a dialogue that confirms computer win
					JOptionPane.showMessageDialog(frame,
							Board.getInstance().getHumanPlayer().getPlayerName() + " Accused " + humanSolution.person.getCardName()
									+ " of MURDER in the " + humanSolution.room.getCardName() + " with the "
									+ humanSolution.weapon.getCardName() + " \n WHICH IS CORRECT!",
							"Too Bad GAME OVER", gameWon.INFORMATION_MESSAGE);
					System.exit(0);
				} else {
					// pop up a dialougue that says solution is wrong
					JOptionPane.showMessageDialog(frame,
							Board.getInstance().getHumanPlayer().getPlayerName() + " Accused " + humanSolution.person.getCardName()
									+ " of MURDER in the " + humanSolution.room.getCardName() + " with the "
									+ humanSolution.weapon.getCardName() + " \n which is WRONG!",
							"Accusation Made", gameWon.INFORMATION_MESSAGE);
					Board.getInstance().setHumanHasFinishedTurn(true);
				}
			

				
			}
		});
	}

}
