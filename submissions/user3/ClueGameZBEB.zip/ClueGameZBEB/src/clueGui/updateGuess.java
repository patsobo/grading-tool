package clueGui;

import java.awt.GridLayout;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;


import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import clueGame.Board;
import clueGame.Solution;

public class updateGuess extends JPanel{
	private static JTextArea guess;
	public Board board = Board.getInstance();
	
	public updateGuess() {
		setLayout(new GridLayout(1,2));
		setBorder(new TitledBorder(new EtchedBorder(), "Guess"));
		guess = new JTextArea(3, 10);
		add(guess);
	}
	
	
	public static void update(String[] playerGuess) {
		String name = playerGuess[0] + "\n" + playerGuess[1] + "\n" + playerGuess[2];
		guess.setText(name);
	}
	
	public void setPlayerGuess() {
		String[] playerGuess = board.getPlayerGuess();
		update(playerGuess);
	}
	
	public static void setHumanGuess(Solution guess) {
		Solution humanGuess = guess;
		String[] values = new String[3];
		values[0] = humanGuess.person.getCardName();
		values[1] = humanGuess.weapon.getCardName();
		values[2] = humanGuess.room.getCardName();
		update(values);
	}
	
	
}
