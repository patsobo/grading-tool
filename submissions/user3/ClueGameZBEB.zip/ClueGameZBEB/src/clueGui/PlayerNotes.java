package clueGui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.Border;

import clueGame.Card;

public class PlayerNotes extends JPanel {

	private static final long serialVersionUID = -3036342458271396803L;
	private ArrayList<Card> person;
	private ArrayList<Card> weapons;
	private ArrayList<Card> rooms;

	
	public PlayerNotes(ArrayList<Card> people, ArrayList<Card> rooms, ArrayList<Card> weapons) {
		this.person = people;
		this.weapons = weapons;
		this.rooms = rooms;
		this.setSize(new Dimension(1300, 800));
		this.createLayout();
	}

	private void createLayout() {

		// Give the display two rows
		this.setLayout(new GridLayout(3, 2));

		// Create check Boxes and Combo Boxes for all 3 card types
		createIcons(person, "Who's hands are clean?", 0);
		createIcons(rooms, "Locations Determined Safe", 1);
		createIcons(weapons, "Whats not bloody?", 2);
	}

	private void createIcons(ArrayList<Card> object, String borderTitle, int index) {
		// player Notes display
		JPanel checkBoxDisplay = new JPanel();
		checkBoxDisplay.setLayout(new GridLayout(0, 2));
		JPanel comboBoxDisplay = new JPanel();
		JComboBox<String> guess = new JComboBox<String>();

		// Make a subpanel border for people cards
		Border border = BorderFactory.createTitledBorder(borderTitle);
		checkBoxDisplay.setBorder(border);
		Border borderComboBox = BorderFactory.createTitledBorder("Your Best Guess" + index);
		comboBoxDisplay.setBorder(borderComboBox);

		// Add people notes
		for (Card c : object) {
			//Add a new check box
			JCheckBox box = new JCheckBox(c.getCardName());
			checkBoxDisplay.add(box);
			
			//Add a new Item to combo box
			guess.addItem(c.getCardName());
			comboBoxDisplay.add(guess);
		}
		this.add(checkBoxDisplay);
		this.add(comboBoxDisplay);
	}
}
