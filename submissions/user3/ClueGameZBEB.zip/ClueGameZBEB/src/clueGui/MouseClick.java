package clueGui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.HumanPlayer;
import clueGame.Player;

public class MouseClick implements MouseListener {
	Board board;

	public MouseClick() {
		this.board = Board.getInstance();
	}

	public void mouseClicked(MouseEvent e) {
		Set<BoardCell> targets = board.getTargets();
		BoardCell targetCell;
		Point i = e.getPoint();
		
		targetCell = board.getCellAt((int) i.getY() / BoardCell.BOARD_SPACE_DIMENSION, (int) i.getX() / BoardCell.BOARD_SPACE_DIMENSION);
		
		if (targets.contains(targetCell)) {
			board.allowedToMakeAccusation = false;
			Player p = board.getHumanPlayer();
			board.setHumanHasFinishedTurn(true);
			if (targetCell.isDoorway() == true) {
				p.movePlayer(targetCell);
				GameControl.setSuggestionFrame(true);

			}else {
				p.movePlayer(targetCell);
				board.setHumanHasFinishedTurn(true);
			}

			board.finishMove();
			
		} else {
			JFrame frame = new JFrame();
			JOptionPane wrong = new JOptionPane();
			wrong.showMessageDialog(frame, "Invalid position", "Try again", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		mouseClicked(e);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

}
