package clueGui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import clueGame.Board;

public class BoardGui extends JPanel {
	
	Board board;
	
	
	public BoardGui() {
        this.setSize(new Dimension(2000, 2000));
        this.setLayout(new FlowLayout(FlowLayout.LEFT));
        
    }

    public void drawWalkway(Graphics g) {
    	super.paintComponent(g);
    	board.paintComponent(g);
    }
}
